extends Area2D
@export var damage: int = 18
var cooldown := false
func _ready() -> void:
    body_entered.connect(_on_body)
    $AnimatedSprite2D.play("idle")
func _on_body(body: Node) -> void:
    if cooldown or not body.is_in_group("player"):
        return
    cooldown = true
    if body.has_method("take_damage"):
        body.take_damage(damage)
    await get_tree().create_timer(0.8).timeout
    cooldown = false
