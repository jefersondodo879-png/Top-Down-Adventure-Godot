extends Node2D
@export var animation_name: String = "idle"
func _ready() -> void:
    if has_node("AnimatedSprite2D"):
        $AnimatedSprite2D.play(animation_name)
