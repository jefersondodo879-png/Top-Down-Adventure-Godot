extends StaticBody2D
var opened := false
func _ready() -> void:
    add_to_group("interactables")
func interact(_player: Node) -> void:
    if opened:
        return
    if not GameState.use_item("key", 1):
        GameState.message.emit("A porta está trancada. Encontre uma chave.")
        return
    opened = true
    $AnimatedSprite2D.play("open")
    collision_layer = 0
    collision_mask = 0
    GameState.message.emit("Porta antiga destrancada.")
