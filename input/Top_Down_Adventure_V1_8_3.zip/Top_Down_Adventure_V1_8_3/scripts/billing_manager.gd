extends Node

signal purchase_completed(product_id: String, premium_amount: int)

const PRODUCTS := {
    "gem_pack_small": 50,
    "gem_pack_medium": 120,
    "gem_pack_large": 300,
}

func purchase_product(product_id: String) -> bool:
    if not PRODUCTS.has(product_id):
        GameState.message.emit("Produto premium inválido.")
        return false
    if OS.has_feature("android"):
        GameState.message.emit("Google Play Billing: o adaptador de produção será conectado antes da publicação. Nenhuma cobrança foi feita.")
        return false
    if not OS.is_debug_build() and not Engine.is_editor_hint():
        GameState.message.emit("Compras premium de teste estão desativadas nesta build.")
        return false
    var amount := int(PRODUCTS[product_id])
    GameState.add_premium_coins(amount)
    purchase_completed.emit(product_id, amount)
    GameState.message.emit("COMPRA DE TESTE: +%d gemas. No Android publicado isso usará Google Play Billing." % amount)
    return true
