extends CanvasLayer

@export var show_on_desktop: bool = false
@export var joystick_radius: float = 42.0

var move_vector := Vector2.ZERO
var joystick_touch_id: int = -1
var ui_blocked: bool = false
var should_show_controls: bool = false

@onready var touch_root: Control = $TouchRoot
@onready var joystick_base: Control = $TouchRoot/JoystickBase
@onready var joystick_knob: Control = $TouchRoot/JoystickBase/Knob

func _ready() -> void:
    add_to_group("mobile_controls")
    should_show_controls = show_on_desktop or OS.has_feature("android") or OS.has_feature("mobile") or DisplayServer.is_touchscreen_available()
    touch_root.visible = should_show_controls
    $TouchRoot/BtnAttack.pressed.connect(_attack_pressed)
    $TouchRoot/BtnAction.pressed.connect(_action_pressed)
    $TouchRoot/BtnPotion.pressed.connect(_potion_pressed)
    $TouchRoot/BtnSummon.pressed.connect(_summon_pressed)
    $TouchRoot/BtnInventory.pressed.connect(_inventory_pressed)
    $TouchRoot/BtnShop.pressed.connect(_shop_pressed)
    _reset_knob()

func set_ui_blocked(blocked: bool) -> void:
    ui_blocked = blocked
    move_vector = Vector2.ZERO
    joystick_touch_id = -1
    _reset_knob()
    touch_root.visible = should_show_controls and not ui_blocked

func get_move_vector() -> Vector2:
    return Vector2.ZERO if ui_blocked else move_vector

func _input(event: InputEvent) -> void:
    if not touch_root.visible or ui_blocked:
        return
    if event is InputEventScreenTouch:
        var touch := event as InputEventScreenTouch
        if touch.pressed and joystick_touch_id == -1 and joystick_base.get_global_rect().has_point(touch.position):
            joystick_touch_id = touch.index
            _update_joystick(touch.position)
        elif not touch.pressed and touch.index == joystick_touch_id:
            joystick_touch_id = -1
            move_vector = Vector2.ZERO
            _reset_knob()
    elif event is InputEventScreenDrag:
        var drag := event as InputEventScreenDrag
        if drag.index == joystick_touch_id:
            _update_joystick(drag.position)

func _update_joystick(screen_position: Vector2) -> void:
    var rect := joystick_base.get_global_rect()
    var center := rect.position + rect.size * 0.5
    var delta := screen_position - center
    move_vector = (delta / joystick_radius).limit_length(1.0)
    var local_center := joystick_base.size * 0.5
    joystick_knob.position = local_center + move_vector * joystick_radius - joystick_knob.size * 0.5

func _reset_knob() -> void:
    if joystick_knob == null or joystick_base == null:
        return
    joystick_knob.position = joystick_base.size * 0.5 - joystick_knob.size * 0.5

func _player() -> Node:
    return get_tree().get_first_node_in_group("player")

func _attack_pressed() -> void:
    var player := _player()
    if player != null and player.has_method("request_attack"):
        player.request_attack()

func _action_pressed() -> void:
    var player := _player()
    if player != null and player.has_method("request_interact"):
        player.request_interact()

func _potion_pressed() -> void:
    var player := _player()
    if player != null and player.has_method("use_potion"):
        player.use_potion()

func _summon_pressed() -> void:
    var player := _player()
    if player != null and player.has_method("request_summon"):
        player.request_summon()

func _inventory_pressed() -> void:
    get_tree().call_group("hud", "toggle_inventory")

func _shop_pressed() -> void:
    get_tree().call_group("hud", "toggle_shop")
