# Top Down Adventure — Reino dos Cristais (V1)

Projeto Godot 4.x criado a partir do **Top Down Adventure Pack v1.0**. O pack original completo foi mantido dentro de `res://assets/` (197 arquivos), e o catálogo de todos os arquivos está em `res://data/asset_catalog.json`.

## O que já existe

- Mundo grande com **240 x 128 tiles** (aprox. 3840 x 2048 px), dividido em 6 regiões editáveis.
- `TileMapLayer` separado em **Ground / Details / Structures** em cada região.
- Vila Verde, Floresta Sussurrante, Terras Altas, Lago de Cristal, Ruínas Cinzentas e Masmorra Antiga.
- 36 missões encadeadas e editáveis em `data/quests.json`.
- NPCs de missão, inimigos, baús, cristais, chaves, poções, fogueiras, armadilhas, portas e portões.
- Combate, dano, morte/respawn, escudo, poções e recompensas de XP/moedas.
- Todos os tipos principais de inimigo do pack: slime, aranha, morcego, fantasma, spinner e bomber plant.
- Animações do player organizadas: idle, correr, ataque, hit, escudo, push, escalada, queda e morte.
- HUD usando as sprites de UI do pack.
- Tilesets do overworld e dungeon configurados como recursos Godot editáveis.

## Controles

- `WASD` ou setas: mover
- `SPACE`: atacar
- `E`: interagir com NPC/baú/fogueira/porta
- `SHIFT`: defender com escudo
- `Q`: usar poção

## Editar o mapa manualmente

Abra qualquer uma destas cenas:

- `scenes/world/regions/01_vila_verde.tscn`
- `scenes/world/regions/02_floresta_sussurrante.tscn`
- `scenes/world/regions/03_terras_altas.tscn`
- `scenes/world/regions/04_lago_de_cristal.tscn`
- `scenes/world/regions/05_ruinas_cinzentas.tscn`
- `scenes/world/regions/06_masmorra_antiga.tscn`

Cada região possui os nós `Ground`, `Details`, `Structures`, `Objects`, `NPCs` e `EnemySpawns`.

O script `region_generator.gd` é `@tool`: quando uma região vazia é aberta, ele monta a base do mapa no próprio editor. Depois disso você pode selecionar os `TileMapLayer` e pintar/apagar/mover tiles manualmente com a ferramenta normal da Godot. Salve a cena para gravar as alterações.

Se quiser reconstruir uma região, marque `regenerate` no Inspector do nó raiz. Se quiser impedir geração automática de uma região vazia, desative `auto_generate_if_empty`.

## Editar estruturas, NPCs e inimigos

- Casas e estruturas de tiles: `Structures` de cada região.
- Objetos: pasta/nó `Objects` dentro de cada região.
- NPCs: nó `NPCs`; cada NPC tem `npc_id`, nome e lista de missões editáveis no Inspector.
- Inimigos: nó `EnemySpawns`; mude a posição ou o campo `enemy_type` no Inspector.
- Missões: `data/quests.json`.
- Tilesets: `resources/tilesets/overworld_tileset.tres` e `dungeon_tileset.tres`.
- Animações: `resources/animations/`.

## Galeria de sprites

A cena `scenes/debug/asset_gallery.tscn` lê `data/asset_catalog.json` e mostra os PNGs do pack em uma galeria. Ela serve para localizar rapidamente uma sprite/strip/spritesheet e aproveitar o conteúdo original sem precisar procurar pasta por pasta.

## V1.3 — estruturas totalmente manuais

As casas e árvores não são mais montadas proceduralmente pelo gerador. Abra uma cena em `scenes/world/regions/` e expanda o nó `Structures` para editar diretamente `Buildings`, `Trees`, `Landmarks` e `Decorations`.

A biblioteca reutilizável está em `scenes/structures/`. Cada estrutura é uma cena separada com sprite e colisão, então você pode mover, duplicar, excluir ou substituir pelo editor 2D. `Ground`, `Details` e `StructureTiles` permanecem como `TileMapLayer` para pintura manual usando os TileSets do pack.

## V1.5
- Ataque corrigido (frames completos, sem desaparecer).
- Câmera mais afastada (zoom 2.15).
- `PlazaFloor` separado e com z-index -25 para edição manual.
- HUD refeita e inventário 27 slots + hotbar 9 slots (I/TAB).
- Música e efeitos sonoros adicionados.

## V1.6 — campanha, PC/Android e loja

- Campanha principal agora é linear de q01 até q36.
- Corrigido o `main.tscn` que apagava os `quest_ids` dos 9 NPCs.
- NPCs de missão exibem nome, marcador `!` para nova missão, `?` para alvo de conversa e dica de interação próxima.
- HUD ganhou orientação da próxima missão/destino.
- Inimigos reaparecem após 10 s; pickups após 18 s; baús são reabastecidos após 25 s. Isso impede missões impossíveis caso o jogador explore antes.
- Movimento continua em 8 direções e agora é possível andar enquanto ataca.
- PC: WASD/setas, clique esquerdo ou Espaço para atacar, E interagir, Q poção, I/TAB inventário, B loja.
- Android landscape: joystick virtual + botões ATK, AÇÃO, POÇÃO, BOLSA e LOJA. A cena `MobileControls` fica editável na `main.tscn`.
- Loja: poções/chaves/cristais por ouro e sistema de gemas premium.
- `BillingManager` simula gemas apenas em build de debug/editor no PC. No Android ele NÃO concede moeda premium até um adaptador real do Google Play Billing ser conectado.

### Estrutura editável
A estrutura anterior foi preservada. Continue abrindo `scenes/main.tscn` e expandindo `World > Regions`. `MobileControls`, `HUD`, `Player` e `Audio` também aparecem como instâncias editáveis.

## V1.6.1 — Correção de NPCs e início da campanha
- Corrigido o caso em que NPCs profundamente instanciados podiam receber `quest_ids` vazio na cena principal.
- A propriedade `npc` de `data/quests.json` agora é a fonte confiável para descobrir as missões de cada NPC.
- `quest_ids` continua como fallback para NPCs personalizados.
- O Ancião Elian consegue resolver q01–q04 pelo `npc_id = "elder"`, inclusive quando o array exportado não chega ao runtime.


## V1.7 — equipamentos, escudo, invocação, ferreiro e mercado

- Novo banco de itens em `data/items.json`, com nome, tipo, raridade, valor de venda, valor de desmontagem e atributos.
- Inventário agora suporta arma, armaduras, sucata e equipamentos encontrados em baús.
- Armaduras de Couro, Ferro e Cristal concedem respectivamente 35, 70 e 120 pontos de escudo.
- Ao equipar uma armadura surge a barra azul de escudo. O escudo absorve dano antes da vida e regenera após alguns segundos sem receber dano.
- O inventário permite selecionar item, equipar/desequipar armadura e quebrar itens para obter Sucata de Forja.
- Poder `R` no PC / botão `INVOCAR` no Android: invoca um Guardião de Cristal temporário que segue o player e ataca inimigos próximos.
- Ferreiro Borin agora possui serviço de forja. A arma equipada pode subir até +10 consumindo Ouro + Sucata.
- Baús não entregam mais tudo automaticamente: abrem uma janela de loot com itens individuais e botão `PEGAR TODOS OS ITENS`.
- Nova `Mercadora Lysa` na Vila Verde. No mercado, itens do inventário podem ser vendidos por Ouro. Itens equipados precisam ser desequipados se for o último exemplar.
- Sistema de janelas modais: Inventário, Baú, Ferreiro, Mercado e Loja nunca ficam sobrepostos. Ao abrir uma janela grande, HUD de missão, hotbar, mensagens e controles de gameplay Android são escondidos até o fechamento.
- `HUD`, `MobileControls`, NPCs de serviço e estruturas continuam editáveis pelo editor da Godot.

### Controles adicionais V1.7
- `R`: invocar Guardião de Cristal.
- Inventário: clique/toque em um slot para ver detalhes, equipar ou quebrar.
- Ferreiro: interaja com Ferreiro Borin quando ele não estiver entregando uma nova missão.
- Mercado: interaja com Mercadora Lysa na Vila Verde.
- Android: botão `INVOCAR` foi adicionado aos controles touch.

## V1.7.2 - HUD / Godot 4.7.2
- HUD de status compactado em 3 linhas para não ultrapassar a resolução-base 640x360.
- Botão LOJA [B] visível no HUD (LOJA no Android).
- O botão e demais elementos de gameplay somem quando uma janela modal é aberta.
- Corrigido aviso/erro de sombreamento do campo `Node.name` em `hud.gd` renomeando a variável local para `item_name`.

## V1.8 — Menu, save, personagens, Passe, inimigos e boss

- Novo menu inicial: Iniciar Jogo, Continuar, Personagens, Passe de Aventura, Online (Em breve), Configurações, Créditos/Licenças e Sair no PC.
- Save JSON em `user://save_v18.json`: campanha, moedas, inventário, equipamentos, upgrades, posição do player, personagem selecionado/desbloqueado e progresso do Passe.
- Personagens: Aventureiro padrão (grátis), Guardião de Ferro (350 ouro) e Slime Real (Passe Premium nível 4).
- O Passe desta versão é uma estrutura de teste. Nenhuma cobrança real é feita; Google Play Billing de produção continua pendente antes da publicação.
- Novos inimigos licenciados: Besouro e Larva Cuspidora; novo boss Mantis Ancestral com 3 fases, barra de vida e recompensas próprias.
- Baú e Mercado agora usam ícones nos itens e limpeza diferida das listas (`queue_free`) para evitar o erro de objeto bloqueado.
- Créditos/licenças: consulte `THIRD_PARTY_ASSETS.md`.

### Observação dos personagens OboroPixel

Os sprites gratuitos fornecidos pelo pack são animações laterais em células 96x96. Eles funcionam como personagens alternativos nesta V1.8 e são espelhados na esquerda/direita; para uma versão final visualmente 100% top-down, o ideal é futuramente substituir/expandir esses personagens por um pack com quatro direções reais.

## V1.8.2 — Inventário e Loja redesenhados

- Inventário redesenhado conforme a referência: painel central grande, título destacado e grade 6x5 com 30 espaços.
- Slots maiores com ícone, quantidade, seleção visual e detalhes do item.
- Barra inferior de ações: `EQUIPAR / USAR`, `QUEBRAR` e `SOLTAR`; ao soltar, 1 unidade vira um pickup no chão e pode ser recolhida novamente.
- Poções podem ser usadas diretamente pelo botão principal; armas e armaduras continuam equipáveis/desequipáveis.
- Loja redesenhada em duas colunas de cards: ícone, nome, descrição, preço e botão `COMPRAR`.
- Recursos por Ouro e produtos Premium ficam visualmente separados por seus cards, mantendo Google Play Billing real bloqueado até a integração de produção.
- Removidos overrides antigos do `main.tscn` que poderiam deformar os slots do novo inventário.
- HUD continua escondida durante Inventário/Loja/Baú/Ferreiro/Mercado/Diálogo para não cobrir as janelas.

## V1.8.3 — Mercado/Ferreiro editáveis no editor

- `scenes/ui/hud.tscn` contém a estrutura visual completa das interfaces. Abra essa cena para editar manualmente tamanhos, posições, fontes, bordas, ícones e espaçamentos.
- `MarketPanel` agora possui `MarketGrid` com 8 cards estáticos (`MarketCard1` a `MarketCard8`) organizados em 2 colunas. O script apenas preenche os dados e esconde cards vazios; os controles visuais não são criados por código.
- `BlacksmithPanel` agora expõe no Scene Tree os cards `WeaponCard` e `UpgradeCard`, com ícone da arma, nível, dano, próximo dano, custos e recursos do jogador.
- A cena principal mantém `HUD` como editable child e mantém as regiões/estruturas do mapa editáveis manualmente.
- Para evitar o aviso de Recovery Mode ao abrir uma cópia nova, o pacote entregue não inclui a pasta de cache `.godot`.


## V1.8.4 — EDIÇÃO COMPLETA NO EDITOR
Abra `res://scenes/00_PROJETO_EDITAVEL.tscn` para editar manualmente Player, mapa, TileMapLayers, regiões, estruturas, NPCs, inimigos, objetos e HUD. Esta é a cena real carregada por Iniciar/Continuar.
