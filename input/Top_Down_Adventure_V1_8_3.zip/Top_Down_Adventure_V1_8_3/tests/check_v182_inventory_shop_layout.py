from pathlib import Path
import re

HUD = Path('scenes/ui/hud.tscn').read_text(encoding='utf-8')
SCRIPT = Path('scripts/hud.gd').read_text(encoding='utf-8')


def test_inventory_matches_reference_structure():
    slots = re.findall(r'\[node name="InventorySlot\d+" type="PanelContainer" parent="HUD/InventoryPanel/VBox/Grid"\]', HUD)
    assert len(slots) == 30, f'expected 30 inventory slots, found {len(slots)}'
    inv = HUD[HUD.index('[node name="InventoryPanel"'):HUD.index('[node name="ShopPanel"')]
    assert 'columns = 6' in inv
    assert 'text = "INVENTÁRIO"' in inv
    assert '[node name="BottomActions" type="HBoxContainer" parent="HUD/InventoryPanel/VBox"]' in inv
    assert 'text = "EQUIPAR / USAR"' in inv
    assert 'text = "QUEBRAR"' in inv
    assert 'text = "SOLTAR"' in inv


def test_shop_uses_two_column_item_cards():
    shop = HUD[HUD.index('[node name="ShopPanel"'):HUD.index('[node name="LootPanel"')]
    assert 'text = "LOJA"' in shop
    assert '[node name="Products" type="GridContainer" parent="HUD/ShopPanel/VBox"]' in shop
    assert 'columns = 2' in shop
    for card in ['PotionCard', 'KeyCard', 'CrystalCard', 'GemCard', 'AdventureKitCard']:
        assert f'[node name="{card}" type="PanelContainer" parent="HUD/ShopPanel/VBox/Products"]' in shop
    assert 'COMPRAR' in shop


def test_hud_script_has_drop_action_and_new_shop_paths():
    assert 'func _drop_selected() -> void:' in SCRIPT
    assert '$HUD/InventoryPanel/VBox/BottomActions/Drop' in SCRIPT
    assert '$HUD/ShopPanel/VBox/Products/PotionCard/Body/Buy' in SCRIPT
    assert '$HUD/ShopPanel/VBox/Products/AdventureKitCard/Body/Buy' in SCRIPT

def test_main_scene_does_not_override_inventory_slot_layout():
    main = Path('scenes/main.tscn').read_text(encoding='utf-8')
    assert 'parent="HUD/HUD/InventoryPanel/' not in main, 'main.tscn deep overrides would distort the redesigned inventory slots'

def test_drop_action_creates_a_world_pickup():
    script = Path('scripts/hud.gd').read_text(encoding='utf-8')
    assert 'DROPPED_ITEM_SCENE' in script
    assert 'DROPPED_ITEM_SCENE.instantiate()' in script
    assert 'dropped.setup(selected_inventory_item, 1)' in script
    assert Path('scenes/objects/dropped_item.tscn').exists()
    assert Path('scripts/dropped_item.gd').exists()
