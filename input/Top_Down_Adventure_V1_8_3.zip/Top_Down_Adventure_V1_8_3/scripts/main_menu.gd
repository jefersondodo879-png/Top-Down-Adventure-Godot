extends Control

@onready var continue_button: Button = $Root/MainPanel/VBox/ContinueGame
@onready var exit_button: Button = $Root/MainPanel/VBox/Exit
@onready var main_panel: PanelContainer = $Root/MainPanel
@onready var characters_panel: PanelContainer = $Root/CharactersPanel
@onready var pass_panel: PanelContainer = $Root/PassPanel
@onready var settings_panel: PanelContainer = $Root/SettingsPanel
@onready var credits_panel: PanelContainer = $Root/CreditsPanel
@onready var profile_label: Label = $Root/Profile
@onready var character_status: Label = $Root/CharactersPanel/VBox/Status
@onready var hero_button: Button = $Root/CharactersPanel/VBox/Hero
@onready var soldier_button: Button = $Root/CharactersPanel/VBox/Soldier
@onready var slime_button: Button = $Root/CharactersPanel/VBox/Slime
@onready var pass_status: Label = $Root/PassPanel/VBox/Status
@onready var activate_pass_button: Button = $Root/PassPanel/VBox/ActivatePass
@onready var master_volume: HSlider = $Root/SettingsPanel/VBox/MasterVolume
@onready var fullscreen: CheckButton = $Root/SettingsPanel/VBox/Fullscreen

func _ready() -> void:
	if SaveManager.has_save():
		SaveManager.load_game()
	continue_button.disabled = not SaveManager.has_save()
	exit_button.visible = not OS.has_feature("android")
	$Root/MainPanel/VBox/StartGame.pressed.connect(_start_game)
	continue_button.pressed.connect(_continue_game)
	$Root/MainPanel/VBox/Characters.pressed.connect(func(): _show_panel(characters_panel))
	$Root/MainPanel/VBox/AdventurePass.pressed.connect(func(): _show_panel(pass_panel))
	$Root/MainPanel/VBox/Settings.pressed.connect(func(): _show_panel(settings_panel))
	$Root/MainPanel/VBox/Credits.pressed.connect(func(): _show_panel(credits_panel))
	exit_button.pressed.connect(func(): get_tree().quit())
	$Root/CharactersPanel/VBox/Back.pressed.connect(_show_main)
	$Root/PassPanel/VBox/Back.pressed.connect(_show_main)
	$Root/SettingsPanel/VBox/Back.pressed.connect(_save_settings_and_back)
	$Root/CreditsPanel/VBox/Back.pressed.connect(_show_main)
	hero_button.pressed.connect(func(): _character_action("hero"))
	soldier_button.pressed.connect(func(): _character_action("soldier"))
	slime_button.pressed.connect(func(): _character_action("slime"))
	activate_pass_button.pressed.connect(_activate_pass)
	var cfg := SaveManager.get_settings()
	master_volume.value = float(cfg.get("master_volume", 0.85)) * 100.0
	fullscreen.button_pressed = bool(cfg.get("fullscreen", false))
	fullscreen.visible = not OS.has_feature("android")
	GameState.profile_changed.connect(_refresh_profile)
	GameState.stats_changed.connect(_refresh_profile)
	_refresh_profile()

func _start_game() -> void:
	SaveManager.start_new_game()
	get_tree().change_scene_to_file("res://scenes/00_PROJETO_EDITAVEL.tscn")

func _continue_game() -> void:
	if SaveManager.load_game():
		get_tree().change_scene_to_file("res://scenes/00_PROJETO_EDITAVEL.tscn")

func _show_panel(panel: Control) -> void:
	main_panel.visible = false
	characters_panel.visible = panel == characters_panel
	pass_panel.visible = panel == pass_panel
	settings_panel.visible = panel == settings_panel
	credits_panel.visible = panel == credits_panel
	_refresh_profile()

func _show_main() -> void:
	characters_panel.visible = false
	pass_panel.visible = false
	settings_panel.visible = false
	credits_panel.visible = false
	main_panel.visible = true
	continue_button.disabled = not SaveManager.has_save()
	_refresh_profile()

func _save_settings_and_back() -> void:
	SaveManager.update_settings({
		"master_volume": clampf(master_volume.value / 100.0, 0.0, 1.0),
		"fullscreen": fullscreen.button_pressed
	})
	_show_main()

func _character_action(character_id: String) -> void:
	if GameState.is_character_unlocked(character_id):
		GameState.select_character(character_id)
	elif character_id == "soldier":
		GameState.unlock_character_with_coins(character_id)
		if GameState.is_character_unlocked(character_id):
			GameState.select_character(character_id)
	else:
		character_status.text = "Slime Real é liberado no nível 4 do Passe Premium."
	if SaveManager.has_save():
		SaveManager.save_game()
	_refresh_profile()

func _activate_pass() -> void:
	if GameState.adventure_pass_owned:
		pass_status.text = "Passe Premium já está ativo."
		return
	if OS.has_feature("android"):
		pass_status.text = "Google Play Billing de produção ainda não está conectado. Nenhuma cobrança foi feita."
		return
	if OS.is_debug_build() or Engine.is_editor_hint():
		GameState.set_adventure_pass_owned(true)
		if SaveManager.has_save():
			SaveManager.save_game()
		pass_status.text = "PASSE PREMIUM ATIVADO PARA TESTE NO PC."
		_refresh_profile()
	else:
		pass_status.text = "Passe Premium disponível somente após conectar o Google Play Billing."

func _refresh_profile() -> void:
	var selected_name := String(GameState.get_character_definition(GameState.selected_character).get("name", "Aventureiro"))
	profile_label.text = "Perfil  •  Ouro %d  •  Gemas %d  •  Personagem: %s" % [GameState.coins, GameState.premium_coins, selected_name]
	hero_button.text = _character_button_text("hero", "GRÁTIS")
	soldier_button.text = _character_button_text("soldier", "350 OURO")
	slime_button.text = _character_button_text("slime", "PASSE NV.4")
	character_status.text = "Selecionado: %s\nPersonagens liberados ficam salvos no perfil." % selected_name
	var pass_level := GameState.get_pass_level()
	pass_status.text = "Nível do Passe: %d/10   •   XP: %d\nPremium: %s\nRecompensa especial NV.4: Slime Real" % [pass_level, GameState.pass_xp, "ATIVO" if GameState.adventure_pass_owned else "INATIVO"]
	activate_pass_button.disabled = GameState.adventure_pass_owned
	activate_pass_button.text = "PASSE PREMIUM ATIVO" if GameState.adventure_pass_owned else "ATIVAR PASSE (TESTE PC)"

func _character_button_text(character_id: String, locked_text: String) -> String:
	var definition := GameState.get_character_definition(character_id)
	var char_name := String(definition.get("name", character_id))
	if GameState.is_character_unlocked(character_id):
		return ("✓ " if GameState.selected_character == character_id else "") + char_name + "  •  SELECIONAR"
	return "🔒 %s  •  %s" % [char_name, locked_text]
