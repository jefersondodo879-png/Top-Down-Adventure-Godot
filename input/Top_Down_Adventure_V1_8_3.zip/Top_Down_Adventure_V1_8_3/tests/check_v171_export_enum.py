from pathlib import Path


def test_no_export_enum_has_empty_option():
    bad = []
    for path in Path('scripts').glob('*.gd'):
        text = path.read_text(encoding='utf-8')
        if '@export_enum(""' in text:
            bad.append(str(path))
    assert not bad, f'Invalid empty @export_enum option in: {bad}'


def test_quest_npc_service_default_is_none():
    text = Path('scripts/quest_npc.gd').read_text(encoding='utf-8')
    assert '@export_enum("none", "blacksmith", "market")' in text
    assert 'var service_type: String = "none"' in text
