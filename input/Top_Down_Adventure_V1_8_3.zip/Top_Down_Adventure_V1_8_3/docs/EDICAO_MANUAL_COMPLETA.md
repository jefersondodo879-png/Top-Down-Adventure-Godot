# EDIÇÃO MANUAL COMPLETA — V1.8.4

Abra `res://scenes/00_PROJETO_EDITAVEL.tscn` para editar o jogo real usado por **Iniciar** e **Continuar**.

## Estrutura principal
- `World` → mapa completo e as 6 regiões.
- `World/Regions/<Região>/Ground` → chão em TileMapLayer.
- `World/Regions/<Região>/Details` → detalhes em TileMapLayer.
- `World/Regions/<Região>/StructureTiles` → tiles de estruturas/decoração.
- `World/Regions/<Região>/Structures` → casas, árvores, landmarks e decorações posicionadas manualmente.
- `World/Regions/<Região>/Objects` → baús, pickups, fogueiras, tochas e outros objetos.
- `World/Regions/<Região>/NPCs` → NPCs e serviços.
- `World/Regions/<Região>/EnemySpawns` → inimigos e bosses.
- `Player` → sprite, colisão e câmera do jogador.
- `HUD` → inventário, loja, mercado, ferreiro, baú, hotbar e interface.
- `MobileControls` → controles Android.
- `Audio` → áudio do jogo.

## Importante
A cena `main_menu.tscn` continua sendo a primeira cena do projeto. Ela mostra somente o menu por design. Para editar o gameplay inteiro, use `00_PROJETO_EDITAVEL.tscn`. Essa é agora a mesma cena carregada quando o jogador inicia ou continua uma partida.

As regiões, Player, HUD, Audio e MobileControls estão marcados como **Editable Children**, permitindo expandir a árvore e ajustar manualmente os filhos no editor. Para alterações permanentes diretamente em uma subcena, use o ícone de abrir cena ao lado do nó instanciado.
