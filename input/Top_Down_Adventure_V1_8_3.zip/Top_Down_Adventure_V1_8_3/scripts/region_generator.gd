@tool
extends Node2D

@export_enum("village", "forest", "highlands", "lake", "ruins", "dungeon") var region_type: String = "village"
@export var map_size: Vector2i = Vector2i(80, 64)
@export var seed_value: int = 100
@export var auto_generate_if_empty: bool = true
@export var regenerate_terrain: bool = false
@onready var ground: TileMapLayer = $Ground
@onready var details: TileMapLayer = $Details
@onready var structure_tiles: TileMapLayer = $StructureTiles
@onready var plaza_floor: TileMapLayer = get_node_or_null("PlazaFloor")

func _ready() -> void:
    call_deferred("_ensure_generated")

func _process(_delta: float) -> void:
    if Engine.is_editor_hint() and regenerate_terrain:
        regenerate_terrain = false
        generate_region(true)

func _ensure_generated() -> void:
    if auto_generate_if_empty and ground != null and ground.get_used_cells().is_empty():
        generate_region(false)

func generate_region(clear_first: bool = true) -> void:
    if ground == null or details == null or structure_tiles == null:
        return
    if clear_first:
        ground.clear()
        details.clear()
        structure_tiles.clear()
        if plaza_floor != null:
            plaza_floor.clear()
    var rng := RandomNumberGenerator.new()
    rng.seed = seed_value + abs(region_type.hash())
    if region_type == "dungeon":
        _generate_dungeon(rng)
    else:
        _generate_overworld(rng)

func _set_tile(layer: TileMapLayer, x: int, y: int, atlas: Vector2i) -> void:
    layer.set_cell(Vector2i(x, y), 0, atlas, 0)

func _generate_overworld(rng: RandomNumberGenerator) -> void:
    var grass := Vector2i(2, 0)
    var grass_alt: Array[Vector2i] = [Vector2i(0,0), Vector2i(1,0), Vector2i(2,0), Vector2i(2,1)]
    for y in range(map_size.y):
        for x in range(map_size.x):
            var tile: Vector2i = grass
            if rng.randf() < 0.035:
                tile = grass_alt[rng.randi_range(0, grass_alt.size() - 1)]
            _set_tile(ground, x, y, tile)

    # Caminhos ficam no TileMap editável. Casas, árvores e marcos NÃO são mais gerados aqui.
    for x in range(map_size.x):
        for dy in range(-2, 3):
            _set_tile(details, x, int(map_size.y / 2) + dy, Vector2i(0, 3))
    for y in range(map_size.y):
        for dx in range(-2, 3):
            _set_tile(details, int(map_size.x / 2) + dx, y, Vector2i(0, 3))

    if region_type == "village":
        _terrain_village()
    elif region_type == "forest":
        _terrain_forest(rng)
    elif region_type == "highlands":
        _terrain_highlands(rng)
    elif region_type == "lake":
        _terrain_lake()
    elif region_type == "ruins":
        _terrain_ruins(rng)

func _terrain_village() -> void:
    # Praça central separada em uma camada própria e editável.
    # Fica atrás do player/objetos e usa piso de terra em vez do bloco cinza.
    for y in range(25, 39):
        for x in range(29, 51):
            if plaza_floor != null:
                _set_tile(plaza_floor, x, y, Vector2i(0, 3))
            else:
                _set_tile(details, x, y, Vector2i(0, 3))

func _terrain_forest(rng: RandomNumberGenerator) -> void:
    for _i in range(28):
        var p := Vector2i(rng.randi_range(2, map_size.x - 3), rng.randi_range(2, map_size.y - 3))
        _set_tile(details, p.x, p.y, Vector2i(4 if rng.randf() < 0.5 else 5, 3))

func _terrain_highlands(rng: RandomNumberGenerator) -> void:
    var detail_tiles: Array[Vector2i] = [Vector2i(4,3), Vector2i(5,3), Vector2i(4,4), Vector2i(5,4)]
    for _i in range(95):
        var p := Vector2i(rng.randi_range(2, map_size.x - 3), rng.randi_range(2, map_size.y - 3))
        _set_tile(details, p.x, p.y, detail_tiles[rng.randi_range(0, detail_tiles.size() - 1)])

func _terrain_lake() -> void:
    var center := Vector2(map_size.x * 0.37, map_size.y * 0.36)
    for y in range(5, map_size.y - 5):
        for x in range(4, map_size.x - 4):
            var dx: float = (x - center.x) / 25.0
            var dy: float = (y - center.y) / 17.0
            if dx * dx + dy * dy < 1.0:
                _set_tile(details, x, y, Vector2i(15 + ((x + y) % 3), 10 + ((x * 3 + y) % 3)))

func _terrain_ruins(rng: RandomNumberGenerator) -> void:
    for y in range(11, 53):
        for x in range(10, 70):
            if (x + y) % 5 != 0:
                _set_tile(details, x, y, Vector2i(6 + ((x + y) % 3), 7 + ((x * 2 + y) % 2)))
    var ruin_tiles: Array[Vector2i] = [Vector2i(4,3), Vector2i(5,3), Vector2i(2,4), Vector2i(3,4)]
    for _i in range(55):
        var p := Vector2i(rng.randi_range(3, map_size.x - 4), rng.randi_range(3, map_size.y - 4))
        _set_tile(details, p.x, p.y, ruin_tiles[rng.randi_range(0, ruin_tiles.size() - 1)])

func _generate_dungeon(_rng: RandomNumberGenerator) -> void:
    var floor_tiles: Array[Vector2i] = [Vector2i(0,11), Vector2i(1,11), Vector2i(2,11), Vector2i(3,11), Vector2i(4,11), Vector2i(5,11), Vector2i(6,11), Vector2i(7,11), Vector2i(8,11), Vector2i(9,11)]
    for y in range(map_size.y):
        for x in range(map_size.x):
            _set_tile(ground, x, y, floor_tiles[(x + y * 3) % floor_tiles.size()])

    # As paredes da masmorra ficam em StructureTiles, que continua sendo um TileMapLayer editável.
    for x in range(map_size.x):
        if x < 37 or x > 43:
            _set_tile(structure_tiles, x, 0, Vector2i(1,1))
            _set_tile(structure_tiles, x, map_size.y - 1, Vector2i(1,8))
    for y in range(map_size.y):
        if y < 28 or y > 36:
            _set_tile(structure_tiles, 0, y, Vector2i(0,4))
            _set_tile(structure_tiles, map_size.x - 1, y, Vector2i(5,4))
    for x in range(12, 68):
        if x not in range(36, 44):
            _set_tile(structure_tiles, x, 20, Vector2i(1,1))
            _set_tile(structure_tiles, x, 43, Vector2i(1,8))
    for y in range(8, 57):
        if y not in range(29, 36):
            _set_tile(structure_tiles, 25, y, Vector2i(0,4))
            _set_tile(structure_tiles, 55, y, Vector2i(5,4))
    for x in range(30, 51):
        for y in range(25, 40):
            if (x + y) % 11 == 0:
                _set_tile(details, x, y, Vector2i(8,12))
