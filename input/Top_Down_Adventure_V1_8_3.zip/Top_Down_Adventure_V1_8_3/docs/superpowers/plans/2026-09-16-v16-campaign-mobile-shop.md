# V1.6 Campaign + PC/Android + Shop Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Deliver a playable V1.6 where all 36 quests form one campaign, objectives cannot become permanently impossible, PC/Android controls work, attacking permits movement, and an editable shop is prepared for Google Play monetization.

**Architecture:** Keep region scenes and main.tscn as the editable world source. Strengthen existing GameState/NPC/object scripts rather than replacing the game framework. Add mobile controls and billing as isolated scenes/scripts.

**Tech Stack:** Godot 4.7 GDScript, .tscn text scenes, Python static verification.

**Spec:** `docs/superpowers/specs/2026-09-16-v16-campaign-mobile-shop-design.md`

## Global Constraints
- Target PC Windows and Android landscape.
- Preserve manual editability of world structures in main.tscn.
- Use existing sprite/audio pack; do not generate replacement art.
- Android premium purchases must not grant real paid currency unless a real Play Billing adapter is connected.

---

### Task 1: Campaign integrity
**Files:** Modify `data/quests.json`, `scenes/main.tscn`, `scripts/game_state.gd`; Test `tests/check_v16_campaign.py`.
- [ ] Write a failing static test asserting q01→q36 prerequisites and no empty main-scene NPC overrides.
- [ ] Run the test and confirm failure on V1.5.
- [ ] Make every q02-q36 prerequisite the previous quest and remove `quest_ids = []` overrides from main.tscn.
- [ ] Add campaign helper methods to GameState.
- [ ] Re-run the static test.

### Task 2: Make every objective repeatable/completable
**Files:** Modify `scripts/enemy.gd`, `scripts/pickup.gd`, `scripts/chest.gd`; Test `tests/check_v16_campaign.py`.
- [ ] Extend the failing test to require enemy respawn, pickup respawn, and chest reset.
- [ ] Implement delayed reset without deleting the scene node.
- [ ] Verify region objective capacity and repeatability.

### Task 3: Quest NPC discoverability and HUD guidance
**Files:** Modify `scripts/quest_npc.gd`, `scenes/npcs/quest_npc.tscn`, `scripts/region_trigger.gd`, `scripts/hud.gd`, `scenes/ui/hud.tscn`.
- [ ] Require NameLabel/InteractionHint and quest-NPC group membership in the test.
- [ ] Add !/? marker states, always-visible NPC names and nearby interaction hint.
- [ ] Add campaign guide text to HUD.
- [ ] Verify all nine quest NPCs own the expected quests.

### Task 4: 8-direction movement while attacking + Android controls
**Files:** Modify `scripts/player.gd`, `scenes/player/player.tscn`, `scenes/main.tscn`; Create `scripts/mobile_controls.gd`, `scenes/ui/mobile_controls.tscn`.
- [ ] Require mobile controls and ensure attack does not zero velocity in the test.
- [ ] Refactor player input to combine PC keyboard and mobile analog vector.
- [ ] Allow movement during attack while preserving attack animation timing and hit timing.
- [ ] Add landscape joystick and touch action buttons; instance it in main.tscn as editable.

### Task 5: Gold shop and premium billing bridge
**Files:** Modify `scripts/game_state.gd`, `scripts/hud.gd`, `scenes/ui/hud.tscn`, `project.godot`; Create `scripts/billing_manager.gd`.
- [ ] Require BillingManager, premium balance, ShopPanel and Android-safe purchase behavior in the test.
- [ ] Implement gold purchases and premium balance signals in GameState.
- [ ] Implement desktop simulation / Android non-granting billing bridge.
- [ ] Wire editable shop buttons and B/mobile shop toggle.

### Task 6: Regression and packaging
**Files:** Update `README.md`; run all tests.
- [ ] Run every Python test in `tests/`.
- [ ] Scan all `res://` references for missing files.
- [ ] Confirm main.tscn retains editable World/regions/Player/HUD/Audio/MobileControls paths.
- [ ] Zip the project and run `unzip -t`.
