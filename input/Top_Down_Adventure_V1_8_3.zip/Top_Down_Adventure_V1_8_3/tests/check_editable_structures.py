from pathlib import Path
import sys

root = Path(__file__).resolve().parents[1]
regions = sorted((root/'scenes/world/regions').glob('*.tscn'))
errors=[]
if len(regions) != 6:
    errors.append(f'expected 6 regions, found {len(regions)}')
for p in regions:
    text=p.read_text(encoding='utf-8')
    if '[node name="Structures" type="Node2D" parent="."]' not in text:
        errors.append(f'{p.name}: Structures is not an editable Node2D')
    if '[node name="StructureTiles" type="TileMapLayer" parent="."]' not in text:
        errors.append(f'{p.name}: missing StructureTiles layer')
    if 'parent="Structures/Buildings" instance=' not in text and p.name != '06_masmorra_antiga.tscn':
        errors.append(f'{p.name}: no explicit building instances')
    if 'parent="Structures/Trees" instance=' not in text and p.name not in ('05_ruinas_cinzentas.tscn','06_masmorra_antiga.tscn'):
        errors.append(f'{p.name}: no explicit tree instances')

rg=(root/'scripts/region_generator.gd').read_text(encoding='utf-8')
if '@onready var structures: TileMapLayer = $Structures' in rg:
    errors.append('region_generator still treats Structures as generated TileMapLayer')
if '_place_tree(' in rg or '_place_block(structures' in rg:
    errors.append('region_generator still procedurally creates manual structures')

required=[
    'scenes/structures/house_stone.tscn',
    'scenes/structures/house_red.tscn',
    'scenes/structures/tree_green.tscn',
    'scenes/structures/tree_orange.tscn',
    'scenes/structures/well.tscn',
]
for rel in required:
    if not (root/rel).exists():
        errors.append(f'missing structure library scene: {rel}')

if errors:
    print('FAIL editable structures')
    for e in errors:
        print('-',e)
    sys.exit(1)
print('PASS editable structures')
