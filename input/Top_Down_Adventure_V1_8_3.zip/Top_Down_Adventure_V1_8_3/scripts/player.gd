extends CharacterBody2D

const CRYSTAL_GUARDIAN_SCENE = preload("res://scenes/player/crystal_guardian.tscn")
const DEFAULT_PLAYER_FRAMES = preload("res://resources/animations/player_frames.tres")
const SOLDIER_FRAMES = preload("res://resources/animations/soldier_frames.tres")
const SLIME_PLAYER_FRAMES = preload("res://resources/animations/slime_player_frames.tres")

@export var move_speed: float = 95.0
@export var max_health: int = 100
@export var shield_regen_delay: float = 4.0
@export var shield_regen_rate: float = 18.0
@export var summon_duration: float = 12.0
@export var summon_cooldown: float = 22.0

var health: int = 100
var current_shield: float = 0.0
var max_armor_shield: int = 0
var shield_regen_timer: float = 0.0
var summon_cooldown_remaining: float = 0.0
var active_guardian: Node = null
var facing := Vector2.DOWN
var attack_direction := Vector2.DOWN
var attacking := false
var shielded := false
var dead := false
var alternate_character_visual := false
var position_save_timer: float = 0.0

@onready var sprite: AnimatedSprite2D = $AnimatedSprite2D
@onready var camera: Camera2D = $Camera2D

func _ready() -> void:
    add_to_group("player")
    health = max_health
    _apply_selected_character()
    global_position = GameState.last_player_position
    sprite.play("idle_down")
    camera.limit_left = 0
    camera.limit_top = 0
    camera.limit_right = 3840
    camera.limit_bottom = 2048
    GameState.equipment_changed.connect(_sync_equipment)
    _sync_equipment()

func _apply_selected_character() -> void:
    alternate_character_visual = false
    sprite.flip_h = false
    match GameState.selected_character:
        "soldier":
            sprite.sprite_frames = SOLDIER_FRAMES
            alternate_character_visual = true
        "slime":
            sprite.sprite_frames = SLIME_PLAYER_FRAMES
            alternate_character_visual = true
        _:
            sprite.sprite_frames = DEFAULT_PLAYER_FRAMES

func _sync_visual_facing() -> void:
    if not alternate_character_visual:
        sprite.flip_h = false
        return
    if facing.x < -0.1:
        sprite.flip_h = true
    elif facing.x > 0.1:
        sprite.flip_h = false


func _physics_process(delta: float) -> void:
    GameState.last_player_position = global_position
    position_save_timer += delta
    if position_save_timer >= 8.0 and SaveManager.has_save():
        position_save_timer = 0.0
        SaveManager.save_game()
    if summon_cooldown_remaining > 0.0:
        summon_cooldown_remaining = maxf(0.0, summon_cooldown_remaining - delta)
    _update_shield_regen(delta)
    if GameState.ui_modal_open:
        velocity = Vector2.ZERO
        _update_animation(Vector2.ZERO)
        return
    if dead:
        velocity = Vector2.ZERO
        return
    shielded = Input.is_key_pressed(KEY_SHIFT)
    var input_vec := _movement_input()
    if input_vec != Vector2.ZERO and not attacking:
        facing = input_vec
    velocity = input_vec * move_speed * (0.55 if shielded else 1.0)
    move_and_slide()
    _update_animation(input_vec)

func _movement_input() -> Vector2:
    var input_vec := Vector2.ZERO
    if Input.is_key_pressed(KEY_A) or Input.is_key_pressed(KEY_LEFT): input_vec.x -= 1.0
    if Input.is_key_pressed(KEY_D) or Input.is_key_pressed(KEY_RIGHT): input_vec.x += 1.0
    if Input.is_key_pressed(KEY_W) or Input.is_key_pressed(KEY_UP): input_vec.y -= 1.0
    if Input.is_key_pressed(KEY_S) or Input.is_key_pressed(KEY_DOWN): input_vec.y += 1.0
    var mobile := get_tree().get_first_node_in_group("mobile_controls")
    if mobile != null and mobile.has_method("get_move_vector"):
        var mobile_vec: Vector2 = mobile.get_move_vector()
        if mobile_vec.length() > 0.05:
            input_vec = mobile_vec
    return input_vec.limit_length(1.0)

func _unhandled_input(event: InputEvent) -> void:
    if dead or GameState.ui_modal_open:
        return
    if event is InputEventMouseButton:
        var mouse_event := event as InputEventMouseButton
        if mouse_event.pressed and mouse_event.button_index == MOUSE_BUTTON_LEFT:
            request_attack()
        return
    if not event is InputEventKey or not event.pressed or event.echo:
        return
    var key := (event as InputEventKey).physical_keycode
    if key == KEY_SPACE:
        request_attack()
    elif key == KEY_E:
        request_interact()
    elif key == KEY_Q:
        use_potion()
    elif key == KEY_R:
        request_summon()

func _dir_name() -> String:
    if abs(facing.x) > abs(facing.y):
        return "right" if facing.x > 0 else "left"
    return "down" if facing.y > 0 else "up"

func _dir_name_for(direction: Vector2) -> String:
    if abs(direction.x) > abs(direction.y):
        return "right" if direction.x > 0 else "left"
    return "down" if direction.y > 0 else "up"

func _update_animation(input_vec: Vector2) -> void:
    if attacking:
        return
    _sync_visual_facing()
    var d := _dir_name()
    if shielded:
        sprite.play("shield_" + d)
    elif input_vec == Vector2.ZERO:
        sprite.play("idle_" + d)
    else:
        sprite.play("run_" + d)

func request_attack() -> void:
    if dead or attacking:
        return
    _attack()

func request_interact() -> void:
    if dead:
        return
    _interact()

func request_summon() -> void:
    if dead:
        return
    if summon_cooldown_remaining > 0.0:
        GameState.message.emit("Invocação recarregando: %.0fs" % ceil(summon_cooldown_remaining))
        return
    if active_guardian != null and is_instance_valid(active_guardian):
        GameState.message.emit("O Guardião de Cristal já está ao seu lado.")
        return
    var guardian := CRYSTAL_GUARDIAN_SCENE.instantiate() as Node2D
    get_tree().current_scene.add_child(guardian)
    guardian.global_position = global_position + Vector2(24, 0)
    if guardian.has_method("setup"):
        guardian.setup(self, summon_duration)
    active_guardian = guardian
    summon_cooldown_remaining = summon_cooldown
    GameState.message.emit("Guardião de Cristal invocado por %.0fs!" % summon_duration)

func _attack() -> void:
    attacking = true
    attack_direction = facing.normalized()
    if attack_direction == Vector2.ZERO:
        attack_direction = Vector2.DOWN
    var d := _dir_name_for(attack_direction)
    _sync_visual_facing()
    sprite.play("attack_" + d)
    _play_sfx("attack")
    await get_tree().create_timer(0.18).timeout
    var hit_pos := global_position + attack_direction * 15.0
    for enemy in get_tree().get_nodes_in_group("enemies"):
        if is_instance_valid(enemy) and enemy.visible and enemy.global_position.distance_to(hit_pos) <= 22.0:
            if enemy.has_method("take_damage"):
                enemy.take_damage(GameState.get_weapon_damage() + GameState.level * 2)
    await get_tree().create_timer(0.32).timeout
    attacking = false

func _interact() -> void:
    var nearest: Node2D = null
    var nearest_distance := 40.0
    for node in get_tree().get_nodes_in_group("interactables"):
        if node is Node2D:
            var d := global_position.distance_to((node as Node2D).global_position)
            if d < nearest_distance:
                nearest = node
                nearest_distance = d
    if nearest != null and nearest.has_method("interact"):
        nearest.interact(self)

func _sync_equipment() -> void:
    var previous_max := max_armor_shield
    max_armor_shield = GameState.get_armor_shield()
    if max_armor_shield <= 0:
        current_shield = 0.0
    elif previous_max != max_armor_shield:
        current_shield = float(max_armor_shield)
    else:
        current_shield = minf(current_shield, float(max_armor_shield))

func _update_shield_regen(delta: float) -> void:
    if max_armor_shield <= 0 or current_shield >= float(max_armor_shield):
        return
    if shield_regen_timer > 0.0:
        shield_regen_timer = maxf(0.0, shield_regen_timer - delta)
        return
    current_shield = minf(float(max_armor_shield), current_shield + shield_regen_rate * delta)

func take_damage(amount: int) -> void:
    if dead:
        return
    var block_multiplier := 1.0
    if shielded:
        block_multiplier = 0.35
    var real_damage: int = maxi(1, int(round(float(amount) * block_multiplier)))
    shield_regen_timer = shield_regen_delay
    if current_shield > 0.0:
        var absorbed := mini(real_damage, int(ceil(current_shield)))
        current_shield = maxf(0.0, current_shield - float(absorbed))
        real_damage -= absorbed
    if real_damage > 0:
        health = maxi(0, health - real_damage)
    _play_sfx("hit")
    if health <= 0:
        dead = true
        sprite.play("death")
        GameState.message.emit("Você caiu. Retornando à Vila Verde...")
        await get_tree().create_timer(1.2).timeout
        global_position = Vector2(640, 500)
        GameState.last_player_position = global_position
        health = max_health
        current_shield = float(max_armor_shield)
        dead = false
    elif not attacking:
        sprite.play(("shield_hit_" if shielded else "hit_") + _dir_name())

func heal(amount: int) -> void:
    health = mini(max_health, health + amount)

func use_potion() -> void:
    if health >= max_health:
        GameState.message.emit("Sua vida já está cheia.")
        return
    if GameState.use_item("potion", 1):
        heal(40)
        _play_sfx("potion")
        GameState.message.emit("Poção usada: +40 de vida")
    else:
        GameState.message.emit("Você não tem poções.")

func get_health_ratio() -> float:
    return float(health) / float(max_health)

func get_shield_ratio() -> float:
    if max_armor_shield <= 0:
        return 0.0
    return current_shield / float(max_armor_shield)

func get_shield_values() -> Vector2i:
    return Vector2i(int(round(current_shield)), max_armor_shield)

func get_summon_cooldown() -> float:
    return summon_cooldown_remaining

func _play_sfx(sound_id: String) -> void:
    get_tree().call_group("audio_manager", "play_sfx", sound_id)
