from pathlib import Path
import re, sys, wave

root = Path(__file__).resolve().parents[1]
errors=[]

def need(cond,msg):
    if not cond: errors.append(msg)

player_scene=(root/'scenes/player/player.tscn').read_text(encoding='utf-8')
player_frames=(root/'resources/animations/player_frames.tres').read_text(encoding='utf-8')
hud_scene=(root/'scenes/ui/hud.tscn').read_text(encoding='utf-8')
hud_script=(root/'scripts/hud.gd').read_text(encoding='utf-8')
main=(root/'scenes/main.tscn').read_text(encoding='utf-8')
region=(root/'scenes/world/regions/01_vila_verde.tscn').read_text(encoding='utf-8')
generator=(root/'scripts/region_generator.gd').read_text(encoding='utf-8')

# Attack sheets are 6 frames of 48x32 (down/up) or 32x48 (left/right).
for rid,x,y,w,h in [
    (13,0,0,48,32),(14,48,0,48,32),(15,96,0,48,32),(16,144,0,48,32),(17,192,0,48,32),(18,240,0,48,32),
    (45,0,0,48,32),(46,48,0,48,32),(47,96,0,48,32),(48,144,0,48,32),(49,192,0,48,32),(50,240,0,48,32),
    (77,0,0,32,48),(78,32,0,32,48),(79,64,0,32,48),(80,96,0,32,48),(81,128,0,32,48),(82,160,0,32,48),
    (109,0,0,32,48),(110,32,0,32,48),(111,64,0,32,48),(112,96,0,32,48),(113,128,0,32,48),(114,160,0,32,48),
]:
    block=re.search(rf'\[sub_resource type="AtlasTexture" id="AtlasTexture_{rid}"\]\n(.*?)(?=\n\[sub_resource|\n\[resource\])', player_frames, re.S)
    need(block is not None, f'AtlasTexture_{rid} missing')
    if block:
        need(f'region = Rect2({x}, {y}, {w}, {h})' in block.group(1), f'AtlasTexture_{rid} wrong region')

zoom=re.search(r'zoom = Vector2\(([^,]+),\s*([^\)]+)\)', player_scene)
need(zoom is not None and float(zoom.group(1)) <= 2.3, 'camera is still too close')
need('z_index = 20' in player_scene, 'player must render above floor layers')
need('[node name="PlazaFloor" type="TileMapLayer" parent="."]' in region, 'Vila Verde needs editable PlazaFloor')
need('z_index = -25' in region, 'PlazaFloor should be far behind player')
need('@onready var plaza_floor: TileMapLayer = get_node_or_null("PlazaFloor")' in generator, 'generator must target PlazaFloor')
need('_set_tile(plaza_floor' in generator, 'village plaza must be generated into PlazaFloor')

need('[node name="InventoryPanel" type="PanelContainer" parent="HUD"]' in hud_scene, 'Minecraft-style inventory panel missing')
need(hud_scene.count('parent="HUD/InventoryPanel/') >= 30, 'inventory needs visible editable slot structure')
need('[node name="Hotbar"' in hud_scene, 'hotbar missing')
need('KEY_I' in hud_script and 'inventory_panel.visible = not inventory_panel.visible' in hud_script, 'I key inventory toggle missing')
need('KEY_TAB' in hud_script, 'TAB inventory toggle missing')

need('res://scenes/audio/audio_manager.tscn' in main, 'Audio manager not instanced in main')
need((root/'scripts/audio_manager.gd').exists(), 'audio manager script missing')
for name in ['attack.wav','hit.wav','pickup.wav','chest.wav','inventory.wav','potion.wav','music_loop.wav']:
    p=root/'assets/audio'/name
    need(p.exists(), f'missing audio {name}')
    if p.exists():
        try:
            with wave.open(str(p),'rb') as wf:
                need(wf.getnframes()>100, f'{name} is empty')
        except Exception as e:
            errors.append(f'{name} invalid wav: {e}')

if errors:
    print('FAIL')
    for e in errors: print('-',e)
    sys.exit(1)
print('PASS: V1.5 feature checks')
