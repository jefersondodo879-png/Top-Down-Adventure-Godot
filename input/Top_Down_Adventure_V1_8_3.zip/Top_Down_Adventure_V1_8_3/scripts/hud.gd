extends CanvasLayer

const POTION_TEXTURE = preload("res://assets/Props_Items_(animated)/health_potion_item.png")
const CRYSTAL_STRIP = preload("res://assets/Props_Items_(animated)/crystal_item_anim_strip_6.png")
const KEY_STRIP = preload("res://assets/Props_Items_(animated)/key_item_anim_strip_6.png")
const GENERIC_ITEM_TEXTURE = preload("res://assets/Hud_Ui/select_icon_ui.png")
const DROPPED_ITEM_SCENE = preload("res://scenes/objects/dropped_item.tscn")

@onready var health_cluster: Control = $HUD/HealthCluster
@onready var health_fill: TextureProgressBar = $HUD/HealthCluster/HealthFill
@onready var health_text: Label = $HUD/HealthCluster/HealthText
@onready var shield_cluster: Control = $HUD/ShieldCluster
@onready var shield_bar: ProgressBar = $HUD/ShieldCluster/ShieldBar
@onready var shield_text: Label = $HUD/ShieldCluster/ShieldText
@onready var stats_panel: PanelContainer = $HUD/StatsPanel
@onready var stats_label: Label = $HUD/StatsPanel/Stats
@onready var shop_quick_button: Button = $HUD/ShopQuickButton
@onready var guide_panel: PanelContainer = $HUD/GuidePanel
@onready var guide_text: Label = $HUD/GuidePanel/GuideText
@onready var boss_panel: PanelContainer = $HUD/BossPanel
@onready var boss_name: Label = $HUD/BossPanel/VBox/BossName
@onready var boss_health: ProgressBar = $HUD/BossPanel/VBox/BossHealth
@onready var boss_health_text: Label = $HUD/BossPanel/VBox/BossHealthText
@onready var message_box: PanelContainer = $HUD/MessageBox
@onready var message_label: Label = $HUD/MessageBox/Message
@onready var controls_hint: Label = $HUD/ControlsHint
@onready var inventory_panel: PanelContainer = $HUD/InventoryPanel
@onready var inventory_grid: GridContainer = $HUD/InventoryPanel/VBox/Grid
@onready var inventory_info: Label = $HUD/InventoryPanel/VBox/Info
@onready var item_details_text: Label = $HUD/InventoryPanel/VBox/ItemDetails/HBox/Text
@onready var equip_button: Button = $HUD/InventoryPanel/VBox/BottomActions/Primary
@onready var break_button: Button = $HUD/InventoryPanel/VBox/BottomActions/Break
@onready var drop_button: Button = $HUD/InventoryPanel/VBox/BottomActions/Drop
@onready var hotbar_panel: PanelContainer = $HUD/Hotbar
@onready var hotbar: HBoxContainer = $HUD/Hotbar/Slots
@onready var shop_panel: PanelContainer = $HUD/ShopPanel
@onready var shop_balance: Label = $HUD/ShopPanel/VBox/Header/ShopBalance
@onready var loot_panel: PanelContainer = $HUD/LootPanel
@onready var loot_list: VBoxContainer = $HUD/LootPanel/VBox/LootList
@onready var blacksmith_panel: PanelContainer = $HUD/BlacksmithPanel
@onready var blacksmith_weapon_icon: TextureRect = $HUD/BlacksmithPanel/VBox/Content/WeaponCard/VBox/WeaponIcon
@onready var blacksmith_weapon_name: Label = $HUD/BlacksmithPanel/VBox/Content/WeaponCard/VBox/WeaponName
@onready var blacksmith_weapon_level: Label = $HUD/BlacksmithPanel/VBox/Content/WeaponCard/VBox/WeaponLevel
@onready var blacksmith_current_damage: Label = $HUD/BlacksmithPanel/VBox/Content/WeaponCard/VBox/CurrentDamage
@onready var blacksmith_next_damage: Label = $HUD/BlacksmithPanel/VBox/Content/UpgradeCard/VBox/NextDamage
@onready var blacksmith_gold_icon: TextureRect = $HUD/BlacksmithPanel/VBox/Content/UpgradeCard/VBox/CostRow/GoldIcon
@onready var blacksmith_gold_cost: Label = $HUD/BlacksmithPanel/VBox/Content/UpgradeCard/VBox/CostRow/GoldCost
@onready var blacksmith_scrap_icon: TextureRect = $HUD/BlacksmithPanel/VBox/Content/UpgradeCard/VBox/CostRow/ScrapIcon
@onready var blacksmith_scrap_cost: Label = $HUD/BlacksmithPanel/VBox/Content/UpgradeCard/VBox/CostRow/ScrapCost
@onready var blacksmith_owned_resources: Label = $HUD/BlacksmithPanel/VBox/Content/UpgradeCard/VBox/OwnedResources
@onready var blacksmith_upgrade_button: Button = $HUD/BlacksmithPanel/VBox/Footer/Upgrade
@onready var market_panel: PanelContainer = $HUD/MarketPanel
@onready var market_balance: Label = $HUD/MarketPanel/VBox/Header/Balance
@onready var market_grid: GridContainer = $HUD/MarketPanel/VBox/MarketGrid
@onready var npc_dialogue_panel: PanelContainer = $HUD/NPCDialoguePanel
@onready var npc_dialogue_title: Label = $HUD/NPCDialoguePanel/VBox/Title
@onready var npc_dialogue_text: Label = $HUD/NPCDialoguePanel/VBox/Text

var player: Node = null
var hide_timer: float = 0.0
var guide_timer: float = 0.0
var selected_hotbar: int = 0
var icon_cache: Dictionary = {}
var inventory_item_ids: Array[String] = []
var selected_inventory_item: String = ""
var market_cards: Array[PanelContainer] = []
var market_slot_item_ids: Array[String] = []
var active_chest: Node = null
var active_modal: String = ""

func _ready() -> void:
    GameState.ui_modal_open = false
    add_to_group("hud")
    player = get_tree().get_first_node_in_group("player")
    GameState.inventory_changed.connect(_refresh)
    GameState.equipment_changed.connect(_refresh)
    GameState.quests_changed.connect(_refresh)
    GameState.stats_changed.connect(_refresh)
    GameState.message.connect(_show_message)
    shop_quick_button.pressed.connect(toggle_shop)
    shop_quick_button.text = "LOJA" if OS.has_feature("android") else "LOJA [B]"
    $HUD/InventoryPanel/VBox/Header/CloseInventory.pressed.connect(_close_modal)
    equip_button.pressed.connect(_equip_selected)
    break_button.pressed.connect(_salvage_selected)
    drop_button.pressed.connect(_drop_selected)
    $HUD/LootPanel/VBox/TakeAll.pressed.connect(_take_all_loot)
    $HUD/LootPanel/VBox/CloseLoot.pressed.connect(_close_modal)
    $HUD/BlacksmithPanel/VBox/Footer/Upgrade.pressed.connect(_upgrade_weapon)
    $HUD/BlacksmithPanel/VBox/Footer/CloseBlacksmith.pressed.connect(_close_modal)
    $HUD/MarketPanel/VBox/Footer/CloseMarket.pressed.connect(_close_modal)
    $HUD/ShopPanel/VBox/Products/PotionCard/Body/Buy.pressed.connect(func(): _buy_gold("potion", 5, 120))
    $HUD/ShopPanel/VBox/Products/KeyCard/Body/Buy.pressed.connect(func(): _buy_gold("key", 3, 180))
    $HUD/ShopPanel/VBox/Products/CrystalCard/Body/Buy.pressed.connect(func(): _buy_gold("crystal", 5, 250))
    $HUD/ShopPanel/VBox/Products/GemCard/Body/Buy.pressed.connect(func(): BillingManager.purchase_product("gem_pack_small"))
    $HUD/ShopPanel/VBox/Products/AdventureKitCard/Body/Buy.pressed.connect(func(): GameState.buy_premium_bundle(20))
    $HUD/ShopPanel/VBox/CloseShop.pressed.connect(_close_modal)
    $HUD/NPCDialoguePanel/VBox/Close.pressed.connect(_close_modal)
    $HUD/ShopPanel/VBox/Products/PotionCard/Body/Icon.texture = _icon_for("potion")
    $HUD/ShopPanel/VBox/Products/KeyCard/Body/Icon.texture = _icon_for("key")
    $HUD/ShopPanel/VBox/Products/CrystalCard/Body/Icon.texture = _icon_for("crystal")
    $HUD/ShopPanel/VBox/Products/GemCard/Body/Icon.texture = GENERIC_ITEM_TEXTURE
    $HUD/ShopPanel/VBox/Products/AdventureKitCard/Body/Icon.texture = GENERIC_ITEM_TEXTURE
    _connect_inventory_slots()
    _connect_market_cards()
    blacksmith_gold_icon.texture = GENERIC_ITEM_TEXTURE
    blacksmith_scrap_icon.texture = _icon_for("scrap")
    _refresh()
    _refresh_hotbar_selection()

func _process(delta: float) -> void:
    if player == null:
        player = get_tree().get_first_node_in_group("player")
    if player != null and player.has_method("get_health_ratio"):
        var ratio: float = float(player.get_health_ratio())
        health_fill.value = ratio * 100.0
        health_text.text = "%d%%" % int(round(ratio * 100.0))
    if player != null and player.has_method("get_shield_values"):
        var shield_values: Vector2i = player.get_shield_values()
        shield_cluster.visible = active_modal.is_empty() and shield_values.y > 0
        if shield_values.y > 0:
            shield_bar.value = 100.0 * float(shield_values.x) / float(shield_values.y)
            shield_text.text = "ESCUDO %d/%d" % [shield_values.x, shield_values.y]
    _refresh_boss_hud()
    if hide_timer > 0.0:
        hide_timer -= delta
        if hide_timer <= 0.0:
            message_box.visible = false
    guide_timer -= delta
    if guide_timer <= 0.0:
        guide_timer = 0.25
        _refresh_guide()

func _unhandled_input(event: InputEvent) -> void:
    if not event is InputEventKey:
        return
    var key_event: InputEventKey = event as InputEventKey
    if not key_event.pressed or key_event.echo:
        return
    var key: int = int(key_event.physical_keycode)
    if key == int(KEY_ESCAPE) and not active_modal.is_empty():
        _close_modal()
        get_viewport().set_input_as_handled()
        return
    if key == int(KEY_I) or key == int(KEY_TAB):
        toggle_inventory()
        get_viewport().set_input_as_handled()
        return
    if key == int(KEY_B):
        toggle_shop()
        get_viewport().set_input_as_handled()
        return
    if active_modal.is_empty() and key >= int(KEY_1) and key <= int(KEY_9):
        selected_hotbar = clampi(key - int(KEY_1), 0, 8)
        _refresh_hotbar_selection()

func _open_modal(modal_name: String, panel: Control) -> void:
    _close_all_modals()
    active_modal = modal_name
    panel.visible = true
    GameState.ui_modal_open = true
    _set_gameplay_hud_visible(false)
    get_tree().call_group("mobile_controls", "set_ui_blocked", true)

func _close_all_modals() -> void:
    inventory_panel.visible = false
    shop_panel.visible = false
    loot_panel.visible = false
    blacksmith_panel.visible = false
    market_panel.visible = false
    npc_dialogue_panel.visible = false

func _close_modal() -> void:
    _close_all_modals()
    active_modal = ""
    active_chest = null
    GameState.ui_modal_open = false
    _set_gameplay_hud_visible(true)
    get_tree().call_group("mobile_controls", "set_ui_blocked", false)

func _set_gameplay_hud_visible(value: bool) -> void:
    health_cluster.visible = value
    stats_panel.visible = value
    shop_quick_button.visible = value
    guide_panel.visible = value
    hotbar_panel.visible = value
    controls_hint.visible = value
    message_box.visible = false
    if not value:
        boss_panel.visible = false
    if value and player != null and player.has_method("get_shield_values"):
        var sv: Vector2i = player.get_shield_values()
        shield_cluster.visible = sv.y > 0
    else:
        shield_cluster.visible = false

func toggle_inventory() -> void:
    var should_open := not inventory_panel.visible
    inventory_panel.visible = not inventory_panel.visible
    if not should_open:
        _close_modal()
        return
    _open_modal("inventory", inventory_panel)
    _refresh_inventory_slots()
    get_tree().call_group("audio_manager", "play_sfx", "inventory")

func toggle_shop() -> void:
    if shop_panel.visible:
        _close_modal()
        return
    _open_modal("shop", shop_panel)
    _refresh_shop()
    get_tree().call_group("audio_manager", "play_sfx", "inventory")

func open_loot(chest: Node) -> void:
    active_chest = chest
    _open_modal("loot", loot_panel)
    _refresh_loot()

func open_npc_dialogue(npc_name: String, text: String) -> void:
    npc_dialogue_title.text = npc_name
    npc_dialogue_text.text = text
    _open_modal("npc_dialogue", npc_dialogue_panel)

func open_blacksmith(_npc: Node = null) -> void:
    _open_modal("blacksmith", blacksmith_panel)
    _refresh_blacksmith()

func open_market(_npc: Node = null) -> void:
    _open_modal("market", market_panel)
    _refresh_market()

func _buy_gold(item_id: String, amount: int, price: int) -> void:
    GameState.buy_shop_item(item_id, amount, price)
    _refresh_shop()

func _refresh() -> void:
    stats_label.text = "NV %d   XP %d/%d\nOURO %d   GEMAS %d\nCRISTAIS %d   SUCATA %d" % [
        GameState.level,
        GameState.xp,
        GameState.level * 120,
        GameState.coins,
        GameState.premium_coins,
        int(GameState.inventory.get("crystal", 0)),
        int(GameState.inventory.get("scrap", 0))
    ]
    _refresh_inventory_slots()
    _refresh_hotbar_items()
    _refresh_shop()
    _refresh_blacksmith()
    if market_panel.visible:
        _refresh_market()
    _refresh_guide()

func _connect_inventory_slots() -> void:
    var slots: Array[Node] = inventory_grid.get_children()
    for i in range(slots.size()):
        var slot := slots[i] as Control
        var index := i
        slot.gui_input.connect(func(event: InputEvent): _on_inventory_slot_input(index, event))

func _on_inventory_slot_input(index: int, event: InputEvent) -> void:
    var pressed := false
    if event is InputEventMouseButton:
        var mouse := event as InputEventMouseButton
        pressed = mouse.pressed and mouse.button_index == MOUSE_BUTTON_LEFT
    elif event is InputEventScreenTouch:
        pressed = (event as InputEventScreenTouch).pressed
    if not pressed or index >= inventory_item_ids.size():
        return
    selected_inventory_item = inventory_item_ids[index]
    _refresh_item_details()

func _refresh_inventory_slots() -> void:
    inventory_item_ids = GameState.get_inventory_item_ids()
    var slots: Array[Node] = inventory_grid.get_children()
    for i in range(slots.size()):
        var slot: Control = slots[i] as Control
        var icon: TextureRect = slot.get_node("Icon") as TextureRect
        var count: Label = slot.get_node("Count") as Label
        icon.texture = null
        count.text = ""
        slot.tooltip_text = ""
        slot.modulate = Color.WHITE
        if i >= inventory_item_ids.size():
            continue
        var item_id := inventory_item_ids[i]
        var amount := int(GameState.inventory.get(item_id, 0))
        var definition := GameState.get_item_definition(item_id)
        icon.texture = _icon_for(item_id)
        count.text = str(amount)
        slot.tooltip_text = String(definition.get("name", item_id))
        slot.modulate = Color(0.72, 0.92, 1.0, 1.0) if item_id == selected_inventory_item else Color.WHITE
    if not selected_inventory_item.is_empty() and int(GameState.inventory.get(selected_inventory_item, 0)) <= 0:
        selected_inventory_item = ""
    var weapon_name := String(GameState.get_item_definition(GameState.equipped_weapon).get("name", "Sem arma"))
    var armor_name := "Sem armadura"
    if not GameState.equipped_armor.is_empty():
        armor_name = String(GameState.get_item_definition(GameState.equipped_armor).get("name", GameState.equipped_armor))
    inventory_info.text = "Arma: %s +%d   |   Armadura: %s   |   Sucata: %d" % [weapon_name, GameState.get_weapon_level(), armor_name, int(GameState.inventory.get("scrap", 0))]
    _refresh_item_details()

func _refresh_item_details() -> void:
    if selected_inventory_item.is_empty():
        item_details_text.text = "Selecione um item para ver os detalhes."
        equip_button.text = "EQUIPAR / USAR"
        equip_button.disabled = true
        break_button.disabled = true
        drop_button.disabled = true
        return
    var definition := GameState.get_item_definition(selected_inventory_item)
    var amount := int(GameState.inventory.get(selected_inventory_item, 0))
    var item_type := String(definition.get("type", "item"))
    var rarity := String(definition.get("rarity", "comum")).to_upper()
    var extra := ""
    if item_type == "armor":
        extra = "  Escudo: %d" % int(definition.get("shield", 0))
    elif item_type == "weapon":
        extra = "  Dano: %d  Nível: +%d" % [GameState.get_weapon_damage(), int(GameState.weapon_levels.get(selected_inventory_item, 1))]
    item_details_text.text = "%s x%d  [%s]\n%s%s" % [String(definition.get("name", selected_inventory_item)), amount, rarity, String(definition.get("description", "")), extra]
    var is_equipped_armor := selected_inventory_item == GameState.equipped_armor
    var is_equipped_weapon := selected_inventory_item == GameState.equipped_weapon
    equip_button.disabled = not (item_type == "armor" or item_type == "weapon" or selected_inventory_item == "potion")
    if selected_inventory_item == "potion":
        equip_button.text = "USAR"
    elif is_equipped_armor:
        equip_button.text = "DESEQUIPAR"
        equip_button.disabled = false
    elif is_equipped_weapon:
        equip_button.text = "EQUIPADO"
        equip_button.disabled = true
    elif item_type == "armor" or item_type == "weapon":
        equip_button.text = "EQUIPAR"
    else:
        equip_button.text = "EQUIPAR / USAR"
    break_button.disabled = int(definition.get("salvage_value", 0)) <= 0 or ((is_equipped_armor or is_equipped_weapon) and amount <= 1)
    drop_button.disabled = (is_equipped_armor or is_equipped_weapon) and amount <= 1

func _equip_selected() -> void:
    if selected_inventory_item.is_empty():
        return
    if selected_inventory_item == "potion":
        if player != null and player.has_method("use_potion"):
            player.use_potion()
        _refresh_inventory_slots()
        return
    if selected_inventory_item == GameState.equipped_armor:
        GameState.unequip_armor()
    else:
        GameState.equip_item(selected_inventory_item)
    _refresh_item_details()

func _salvage_selected() -> void:
    if selected_inventory_item.is_empty():
        return
    GameState.salvage_item(selected_inventory_item, 1)
    _refresh_inventory_slots()

func _drop_selected() -> void:
    if selected_inventory_item.is_empty() or player == null or not player is Node2D:
        return
    var amount := int(GameState.inventory.get(selected_inventory_item, 0))
    var is_protected := selected_inventory_item == GameState.equipped_weapon or selected_inventory_item == GameState.equipped_armor
    if is_protected and amount <= 1:
        GameState.message.emit("Desequipe o item antes de soltá-lo.")
        return
    if not GameState.use_item(selected_inventory_item, 1):
        return
    var dropped := DROPPED_ITEM_SCENE.instantiate() as DroppedItem
    var world_parent := (player as Node).get_parent()
    if world_parent == null:
        world_parent = get_tree().current_scene
    world_parent.add_child(dropped)
    dropped.global_position = (player as Node2D).global_position + Vector2(0, 24)
    dropped.setup(selected_inventory_item, 1)
    var definition := GameState.get_item_definition(selected_inventory_item)
    GameState.message.emit("Item solto: %s" % String(definition.get("name", selected_inventory_item)))
    _refresh_inventory_slots()

func _refresh_loot() -> void:
    _clear_container(loot_list)
    if active_chest == null or not is_instance_valid(active_chest) or not active_chest.has_method("get_loot"):
        var empty := Label.new()
        empty.text = "Baú indisponível."
        loot_list.add_child(empty)
        return
    var loot: Dictionary = active_chest.get_loot()
    if loot.is_empty():
        var empty := Label.new()
        empty.text = "Baú vazio."
        loot_list.add_child(empty)
        return
    for raw_id in loot.keys():
        var item_id := String(raw_id)
        var amount := int(loot[item_id])
        var item_name: String = "Ouro" if item_id == "gold" else String(GameState.get_item_definition(item_id).get("name", item_id))
        var button := Button.new()
        button.text = "%s  x%d   —   PEGAR" % [item_name, amount]
        button.icon = _icon_for(item_id) if item_id != "gold" else GENERIC_ITEM_TEXTURE
        button.custom_minimum_size = Vector2(0, 34)
        button.tooltip_text = "Clique/toque para transferir este item para o inventário."
        var captured_id := item_id
        button.pressed.connect(func(): _take_loot_item(captured_id))
        loot_list.add_child(button)

func _take_loot_item(item_id: String) -> void:
    if active_chest == null or not is_instance_valid(active_chest):
        return
    var loot: Dictionary = active_chest.get_loot()
    var amount := int(loot.get(item_id, 0))
    if amount > 0:
        active_chest.take_item(item_id, amount)
    _refresh_loot()
    if active_chest.get_loot().is_empty():
        _close_modal()

func _take_all_loot() -> void:
    if active_chest == null or not is_instance_valid(active_chest):
        return
    active_chest.take_all()
    _close_modal()

func _refresh_blacksmith() -> void:
    if blacksmith_weapon_name == null:
        return
    var weapon_id := GameState.equipped_weapon
    var weapon_def := GameState.get_item_definition(weapon_id)
    var weapon_name := String(weapon_def.get("name", "Sem arma equipada"))
    var weapon_level := GameState.get_weapon_level()
    var current_damage := GameState.get_weapon_damage()
    var is_max_level := weapon_level >= 10
    var next_damage := current_damage if is_max_level else current_damage + 6
    var cost := GameState.get_weapon_upgrade_cost()
    var gold_cost := int(cost.get("gold", 0))
    var scrap_cost := int(cost.get("scrap", 0))
    var owned_scrap := int(GameState.inventory.get("scrap", 0))

    blacksmith_weapon_icon.texture = _icon_for(weapon_id) if not weapon_id.is_empty() else GENERIC_ITEM_TEXTURE
    blacksmith_weapon_name.text = weapon_name
    blacksmith_weapon_level.text = "NÍVEL +%d" % weapon_level if weapon_level > 0 else "SEM ARMA"
    blacksmith_current_damage.text = "DANO ATUAL: %d" % current_damage
    blacksmith_next_damage.text = "NÍVEL MÁXIMO" if is_max_level else "DANO %d → %d" % [current_damage, next_damage]
    blacksmith_gold_cost.text = "—" if is_max_level else str(gold_cost)
    blacksmith_scrap_cost.text = "—" if is_max_level else str(scrap_cost)
    blacksmith_owned_resources.text = "VOCÊ TEM: %d Ouro • %d Sucata" % [GameState.coins, owned_scrap]
    blacksmith_upgrade_button.text = "NÍVEL MÁXIMO" if is_max_level else "EVOLUIR ARMA"
    blacksmith_upgrade_button.disabled = is_max_level or weapon_id.is_empty() or GameState.coins < gold_cost or owned_scrap < scrap_cost

func _upgrade_weapon() -> void:
    GameState.upgrade_weapon()
    _refresh_blacksmith()

func _connect_market_cards() -> void:
    market_cards.clear()
    market_slot_item_ids.clear()
    for i in range(1, 9):
        var card := market_grid.get_node("MarketCard%d" % i) as PanelContainer
        market_cards.append(card)
        market_slot_item_ids.append("")
        var sell_button := card.get_node("Body/Sell") as Button
        sell_button.pressed.connect(_sell_market_slot.bind(i - 1))

func _refresh_market() -> void:
    market_balance.text = "OURO %d" % GameState.coins
    var sellable_ids: Array[String] = []
    for item_id in GameState.get_inventory_item_ids():
        var definition := GameState.get_item_definition(item_id)
        if int(definition.get("sell_value", 0)) > 0:
            sellable_ids.append(item_id)

    for slot_index in range(market_cards.size()):
        var card := market_cards[slot_index]
        if slot_index >= sellable_ids.size():
            market_slot_item_ids[slot_index] = ""
            card.visible = false
            continue

        var item_id := sellable_ids[slot_index]
        var definition := GameState.get_item_definition(item_id)
        var amount := int(GameState.inventory.get(item_id, 0))
        var value := int(definition.get("sell_value", 0))
        var rarity := String(definition.get("rarity", "comum")).to_upper()
        market_slot_item_ids[slot_index] = item_id
        card.visible = true
        (card.get_node("Body/Icon") as TextureRect).texture = _icon_for(item_id)
        (card.get_node("Body/Info/Name") as Label).text = String(definition.get("name", item_id))
        (card.get_node("Body/Info/Meta") as Label).text = "x%d • %s" % [amount, rarity]
        (card.get_node("Body/Info/Price") as Label).text = "%d Ouro" % value
        var sell_button := card.get_node("Body/Sell") as Button
        var last_equipped_copy := (item_id == GameState.equipped_weapon or item_id == GameState.equipped_armor) and amount <= 1
        sell_button.disabled = amount <= 0 or last_equipped_copy
        sell_button.text = "EM USO" if last_equipped_copy else "VENDER"
        sell_button.tooltip_text = "Desequipe antes de vender." if last_equipped_copy else String(definition.get("description", "Vender 1 unidade"))

func _sell_market_slot(slot_index: int) -> void:
    if slot_index < 0 or slot_index >= market_slot_item_ids.size():
        return
    var item_id := market_slot_item_ids[slot_index]
    if item_id.is_empty():
        return
    GameState.sell_item(item_id, 1)
    _refresh_market()

func _clear_container(container: Node) -> void:
    for child in container.get_children():
        child.queue_free()

func _refresh_boss_hud() -> void:
    if boss_panel == null or not active_modal.is_empty():
        if boss_panel != null:
            boss_panel.visible = false
        return
    var active_boss: Node = null
    for boss in get_tree().get_nodes_in_group("bosses"):
        if is_instance_valid(boss) and boss.has_method("is_boss_active") and boss.is_boss_active():
            active_boss = boss
            break
    if active_boss == null:
        boss_panel.visible = false
        return
    boss_panel.visible = true
    boss_name.text = String(active_boss.get_boss_name())
    boss_health.value = float(active_boss.get_boss_health_ratio()) * 100.0
    boss_health_text.text = String(active_boss.get_boss_health_text())


func _refresh_guide() -> void:
    if guide_text == null:
        return
    var quest_id := GameState.get_current_campaign_quest_id()
    if quest_id.is_empty():
        guide_text.text = "CAMPANHA CONCLUÍDA • Reino dos Cristais protegido!"
        return
    var quest: Dictionary = GameState.quests.get(quest_id, {})
    if GameState.active.has(quest_id):
        var event_type := String(quest.get("event", ""))
        var target_id := String(quest.get("target", ""))
        var target_node: Node2D = null
        if event_type == "talk":
            target_node = _find_npc_by_id(target_id)
        elif event_type == "visit":
            target_node = _find_region_trigger(target_id)
        var progress := int(GameState.active.get(quest_id, 0))
        var count := int(quest.get("count", 1))
        var base := "%s • %d/%d" % [String(quest.get("title", quest_id)), progress, count]
        if target_node != null:
            guide_text.text = base + "\nDestino: " + _target_direction_text(target_node)
        else:
            guide_text.text = base + "\n" + String(quest.get("description", ""))
        return
    var giver_id := String(quest.get("npc", ""))
    var giver := _find_npc_by_id(giver_id)
    if giver != null:
        guide_text.text = "PRÓXIMA MISSÃO: %s\nFale com %s • %s" % [String(quest.get("title", quest_id)), String(giver.get("display_name")), _target_direction_text(giver)]
    else:
        guide_text.text = "PRÓXIMA MISSÃO: %s\nProcure o NPC marcado com !" % String(quest.get("title", quest_id))

func _find_npc_by_id(target_id: String) -> Node2D:
    for node in get_tree().get_nodes_in_group("quest_npcs"):
        if node is Node2D and String(node.get("npc_id")) == target_id:
            return node as Node2D
    return null

func _find_region_trigger(target_id: String) -> Node2D:
    for node in get_tree().get_nodes_in_group("region_triggers"):
        if node is Node2D and String(node.get("region_id")) == target_id:
            return node as Node2D
    return null

func _target_direction_text(target: Node2D) -> String:
    if player == null or not player is Node2D:
        return "destino marcado"
    var delta: Vector2 = target.global_position - (player as Node2D).global_position
    var distance_tiles := maxi(0, int(round(delta.length() / 16.0)))
    var direction := _direction_name(delta)
    return "%s • ~%d blocos" % [direction, distance_tiles]

func _direction_name(delta: Vector2) -> String:
    if delta.length() < 8.0:
        return "AQUI"
    var x := ""
    var y := ""
    if abs(delta.x) > 12.0:
        x = "L" if delta.x > 0.0 else "O"
    if abs(delta.y) > 12.0:
        y = "S" if delta.y > 0.0 else "N"
    return y + x if not (x + y).is_empty() else "AQUI"

func _item_ids() -> Array[String]:
    return ["potion", "crystal", "key"]

func _icon_for(item_id: String) -> Texture2D:
    if icon_cache.has(item_id):
        return icon_cache[item_id] as Texture2D
    var texture: Texture2D = GENERIC_ITEM_TEXTURE
    if item_id == "potion":
        texture = POTION_TEXTURE
    elif item_id == "crystal":
        var crystal_atlas: AtlasTexture = AtlasTexture.new()
        crystal_atlas.atlas = CRYSTAL_STRIP
        crystal_atlas.region = Rect2(0, 0, 16, 16)
        texture = crystal_atlas
    elif item_id == "key":
        var key_atlas: AtlasTexture = AtlasTexture.new()
        key_atlas.atlas = KEY_STRIP
        key_atlas.region = Rect2(0, 0, 16, 16)
        texture = key_atlas
    icon_cache[item_id] = texture
    return texture

func _refresh_hotbar_items() -> void:
    var item_ids: Array[String] = _item_ids()
    var slots: Array[Node] = hotbar.get_children()
    for i in range(slots.size()):
        var slot: Control = slots[i] as Control
        var icon: TextureRect = slot.get_node("Icon") as TextureRect
        var count: Label = slot.get_node("Count") as Label
        icon.texture = null
        count.text = ""
        if i >= item_ids.size():
            continue
        var item_id: String = item_ids[i]
        var amount: int = int(GameState.inventory.get(item_id, 0))
        if amount <= 0:
            continue
        icon.texture = _icon_for(item_id)
        count.text = str(amount)
    _refresh_hotbar_selection()

func _refresh_hotbar_selection() -> void:
    var slots: Array[Node] = hotbar.get_children()
    for i in range(slots.size()):
        var slot: Control = slots[i] as Control
        var select_box: TextureRect = slot.get_node("Select") as TextureRect
        select_box.visible = i == selected_hotbar

func _refresh_shop() -> void:
    if shop_balance == null:
        return
    shop_balance.text = "Ouro: %d    Gemas: %d" % [GameState.coins, GameState.premium_coins]

func _show_message(text: String) -> void:
    message_label.text = text
    hide_timer = 4.0
    if active_modal.is_empty():
        message_box.visible = true
