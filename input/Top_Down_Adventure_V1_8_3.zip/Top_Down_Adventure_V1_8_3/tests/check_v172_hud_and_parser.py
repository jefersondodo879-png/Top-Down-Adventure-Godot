from pathlib import Path


def test_hud_script_avoids_node_name_shadow_warning():
    hud = Path('scripts/hud.gd').read_text(encoding='utf-8')
    assert 'var name :=' not in hud


def test_hud_has_visible_shop_quick_button():
    scene = Path('scenes/ui/hud.tscn').read_text(encoding='utf-8')
    assert '[node name="ShopQuickButton" type="Button" parent="HUD"]' in scene
    hud = Path('scripts/hud.gd').read_text(encoding='utf-8')
    assert '$HUD/ShopQuickButton' in hud


def test_stats_hud_is_compact_and_not_overridden_by_large_label_settings():
    scene = Path('scenes/ui/hud.tscn').read_text(encoding='utf-8')
    assert 'text = "NV 1   XP 0/120\\nOURO 0   GEMAS 0\\nCRISTAIS 0   SUCATA 0"' in scene
    main = Path('scenes/main.tscn').read_text(encoding='utf-8')
    assert 'label_settings = SubResource("LabelSettings_nv8jh")' not in main
