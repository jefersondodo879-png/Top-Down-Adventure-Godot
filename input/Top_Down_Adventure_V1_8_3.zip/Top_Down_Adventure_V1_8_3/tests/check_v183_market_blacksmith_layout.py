from pathlib import Path

SCENE = Path('scenes/ui/hud.tscn').read_text(encoding='utf-8')
SCRIPT = Path('scripts/hud.gd').read_text(encoding='utf-8')


def test_market_is_static_editable_two_column_cards():
    assert '[node name="MarketGrid" type="GridContainer" parent="HUD/MarketPanel/VBox"]' in SCENE
    assert 'columns = 2' in SCENE
    for i in range(1, 9):
        assert f'[node name="MarketCard{i}" type="PanelContainer" parent="HUD/MarketPanel/VBox/MarketGrid"]' in SCENE
        assert f'parent="HUD/MarketPanel/VBox/MarketGrid/MarketCard{i}/Body"' in SCENE
        assert f'parent="HUD/MarketPanel/VBox/MarketGrid/MarketCard{i}/Body/Info"' in SCENE
    assert 'MarketItems' not in SCENE
    assert 'SellOne' not in SCENE


def test_market_script_uses_editable_cards_not_runtime_buttons():
    assert 'market_cards' in SCRIPT
    assert '_sell_market_slot' in SCRIPT
    assert 'Button.new()' not in SCRIPT[SCRIPT.index('func _refresh_market()'):SCRIPT.index('func _clear_container')]
    assert '$HUD/MarketPanel/VBox/SellOne' not in SCRIPT


def test_blacksmith_has_visual_weapon_and_cost_sections():
    required = [
        '[node name="WeaponCard" type="PanelContainer" parent="HUD/BlacksmithPanel/VBox/Content"]',
        '[node name="WeaponIcon" type="TextureRect" parent="HUD/BlacksmithPanel/VBox/Content/WeaponCard/VBox"]',
        '[node name="WeaponName" type="Label" parent="HUD/BlacksmithPanel/VBox/Content/WeaponCard/VBox"]',
        '[node name="WeaponLevel" type="Label" parent="HUD/BlacksmithPanel/VBox/Content/WeaponCard/VBox"]',
        '[node name="CurrentDamage" type="Label" parent="HUD/BlacksmithPanel/VBox/Content/WeaponCard/VBox"]',
        '[node name="NextDamage" type="Label" parent="HUD/BlacksmithPanel/VBox/Content/UpgradeCard/VBox"]',
        '[node name="GoldIcon" type="TextureRect" parent="HUD/BlacksmithPanel/VBox/Content/UpgradeCard/VBox/CostRow"]',
        '[node name="GoldCost" type="Label" parent="HUD/BlacksmithPanel/VBox/Content/UpgradeCard/VBox/CostRow"]',
        '[node name="ScrapIcon" type="TextureRect" parent="HUD/BlacksmithPanel/VBox/Content/UpgradeCard/VBox/CostRow"]',
        '[node name="ScrapCost" type="Label" parent="HUD/BlacksmithPanel/VBox/Content/UpgradeCard/VBox/CostRow"]',
        '[node name="OwnedResources" type="Label" parent="HUD/BlacksmithPanel/VBox/Content/UpgradeCard/VBox"]',
    ]
    for node_line in required:
        assert node_line in SCENE
    assert 'WeaponInfo' not in SCENE
    assert 'UpgradeCost' not in SCENE


def test_blacksmith_script_populates_visual_fields():
    for token in ['blacksmith_weapon_icon', 'blacksmith_weapon_name', 'blacksmith_weapon_level',
                  'blacksmith_current_damage', 'blacksmith_next_damage', 'blacksmith_gold_cost',
                  'blacksmith_scrap_cost', 'blacksmith_owned_resources']:
        assert token in SCRIPT
