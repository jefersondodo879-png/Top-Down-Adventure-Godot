from pathlib import Path
import json

ROOT = Path('.')


def test_main_menu_is_entry_scene_and_has_core_buttons():
    project = (ROOT/'project.godot').read_text(encoding='utf-8')
    assert 'run/main_scene="res://scenes/ui/main_menu.tscn"' in project
    menu = (ROOT/'scenes/ui/main_menu.tscn').read_text(encoding='utf-8')
    for name in ['StartGame','ContinueGame','Characters','AdventurePass','Online','Settings','Credits']:
        assert f'name="{name}"' in menu
    assert 'disabled = true' in menu and 'EM BREVE' in menu


def test_save_manager_and_profile_fields_exist():
    project = (ROOT/'project.godot').read_text(encoding='utf-8')
    assert 'SaveManager="*res://scripts/save_manager.gd"' in project
    gs = (ROOT/'scripts/game_state.gd').read_text(encoding='utf-8')
    for token in ['selected_character', 'unlocked_characters', 'adventure_pass_owned', 'pass_xp', 'reset_new_game', 'export_save_data', 'import_save_data']:
        assert token in gs
    sm = (ROOT/'scripts/save_manager.gd').read_text(encoding='utf-8')
    assert 'user://save_v18.json' in sm
    assert 'func has_save()' in sm
    assert 'func save_game()' in sm
    assert 'func load_game()' in sm


def test_character_catalog_and_resources():
    chars = json.loads((ROOT/'data/characters.json').read_text(encoding='utf-8'))
    ids = {c['id'] for c in chars}
    assert {'hero','soldier','slime'} <= ids
    soldier = next(c for c in chars if c['id']=='soldier')
    slime = next(c for c in chars if c['id']=='slime')
    assert soldier['unlock_type'] == 'coins'
    assert int(soldier['unlock_cost']) > 0
    assert slime['unlock_type'] == 'pass'
    assert (ROOT/'resources/animations/soldier_frames.tres').exists()
    assert (ROOT/'resources/animations/slime_player_frames.tres').exists()
    player = (ROOT/'scripts/player.gd').read_text(encoding='utf-8')
    assert '_apply_selected_character' in player
    assert 'GameState.selected_character' in player


def test_insect_enemies_boss_and_boss_hud_exist():
    for p in [
        ROOT/'scripts/insect_enemy.gd',
        ROOT/'scripts/acid_projectile.gd',
        ROOT/'scenes/enemies/insect_enemy.tscn',
        ROOT/'scenes/enemies/acid_projectile.tscn',
        ROOT/'resources/animations/beetle_frames.tres',
        ROOT/'resources/animations/maggot_frames.tres',
        ROOT/'resources/animations/mantis_frames.tres',
    ]:
        assert p.exists(), p
    insect = (ROOT/'scripts/insect_enemy.gd').read_text(encoding='utf-8')
    assert 'mantis_boss' in insect
    assert 'add_to_group("bosses")' in insect
    hud = (ROOT/'scenes/ui/hud.tscn').read_text(encoding='utf-8')
    assert 'name="BossPanel"' in hud and 'name="BossHealth"' in hud
    hudgd = (ROOT/'scripts/hud.gd').read_text(encoding='utf-8')
    assert '_refresh_boss_hud' in hudgd


def test_third_party_licenses_are_documented():
    third = (ROOT/'THIRD_PARTY_ASSETS.md').read_text(encoding='utf-8')
    assert 'Ponk' in third and 'CC BY 4.0' in third
    assert 'OboroPixel' in third and 'commercial' in third.lower()
    assert (ROOT/'assets/ThirdParty/OboroPixel_Characters/License.txt').exists()


def test_dynamic_modal_lists_use_deferred_cleanup_and_icons():
    hud = (ROOT/'scripts/hud.gd').read_text(encoding='utf-8')
    assert 'child.queue_free()' in hud
    assert 'button.icon = _icon_for(item_id)' in hud
