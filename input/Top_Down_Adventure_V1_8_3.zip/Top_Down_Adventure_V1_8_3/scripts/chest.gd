extends StaticBody2D

@export var reset_delay: float = 35.0
var opened := false
var reset_scheduled := false
var loot: Dictionary = {}
@onready var sprite: AnimatedSprite2D = $AnimatedSprite2D

func _ready() -> void:
    add_to_group("interactables")
    sprite.play("closed")

func interact(_player: Node) -> void:
    if not opened:
        opened = true
        loot = _generate_loot()
        sprite.play("open")
        GameState.report_event("interact", "chest", 1)
    if loot.is_empty():
        GameState.message.emit("Este baú está vazio. Ele será reabastecido em breve.")
        _schedule_reset()
        return
    get_tree().call_group("hud", "open_loot", self)

func _generate_loot() -> Dictionary:
    var result: Dictionary = {}
    result["gold"] = randi_range(18, 45)
    result["crystal"] = randi_range(1, 2)
    if randf() < 0.55:
        result["potion"] = 1
    if randf() < 0.30:
        result["scrap"] = randi_range(1, 3)
    var roll := randf()
    if roll < 0.07:
        result["armor_crystal"] = 1
    elif roll < 0.20:
        result["armor_iron"] = 1
    elif roll < 0.38:
        result["armor_leather"] = 1
    return result

func get_loot() -> Dictionary:
    return loot.duplicate(true)

func take_item(item_id: String, amount: int = 1) -> bool:
    var have := int(loot.get(item_id, 0))
    if amount <= 0 or have < amount:
        return false
    loot[item_id] = have - amount
    if int(loot[item_id]) <= 0:
        loot.erase(item_id)
    if item_id == "gold":
        GameState.coins += amount
        GameState.stats_changed.emit()
    else:
        GameState.add_item(item_id, amount)
    if loot.is_empty():
        GameState.message.emit("Baú esvaziado.")
        _schedule_reset()
    return true

func take_all() -> void:
    var snapshot := loot.duplicate(true)
    for item_id in snapshot.keys():
        take_item(String(item_id), int(snapshot[item_id]))

func _schedule_reset() -> void:
    if reset_scheduled:
        return
    reset_scheduled = true
    await get_tree().create_timer(reset_delay).timeout
    if loot.is_empty():
        opened = false
        sprite.play("closed")
    reset_scheduled = false
