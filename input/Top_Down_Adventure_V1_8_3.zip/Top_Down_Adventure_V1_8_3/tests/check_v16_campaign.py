from pathlib import Path
from collections import Counter
import json, re

ROOT = Path(__file__).resolve().parents[1]

def text(rel):
    return (ROOT / rel).read_text(encoding='utf-8')

def test_linear_campaign_and_main_overrides():
    quests = json.loads(text('data/quests.json'))
    assert [q['id'] for q in quests] == [f'q{i:02d}' for i in range(1, 37)]
    for i, q in enumerate(quests):
        expected = '' if i == 0 else f'q{i:02d}'
        assert q.get('prereq', '') == expected, (q['id'], q.get('prereq'), expected)
    assert 'quest_ids = []' not in text('scenes/main.tscn')


def test_npc_ownership_matches_quest_data():
    quests = json.loads(text('data/quests.json'))
    all_regions = '\n'.join(text(str(p.relative_to(ROOT))) for p in sorted((ROOT/'scenes/world/regions').glob('*.tscn')))
    blocks = re.findall(r'\[node name="NPC_[^\"]+".*?(?=\n\[node|\Z)', all_regions, re.S)
    owned = {}
    for b in blocks:
        mid = re.search(r'npc_id = "([^"]+)"', b)
        qids = re.search(r'quest_ids = PackedStringArray\((.*?)\)', b)
        if mid and qids:
            owned[mid.group(1)] = re.findall(r'"(q\d+)"', qids.group(1))
    assert len(owned) == 9, owned.keys()
    for q in quests:
        assert q['id'] in owned.get(q['npc'], []), (q['id'], q['npc'])


def test_objective_capacity_and_repeatability():
    files = {p.name: text(str(p.relative_to(ROOT))) for p in (ROOT/'scenes/world/regions').glob('*.tscn')}
    region = {
        'village': files['01_vila_verde.tscn'],
        'forest': files['02_floresta_sussurrante.tscn'],
        'highlands': files['03_terras_altas.tscn'],
        'lake': files['04_lago_de_cristal.tscn'],
        'ruins': files['05_ruinas_cinzentas.tscn'],
        'dungeon': files['06_masmorra_antiga.tscn'],
    }
    def enemies(r): return Counter(re.findall(r'enemy_type = "([^"]+)"', region[r]))
    def pickups(r): return Counter(re.findall(r'item_id = "([^"]+)"', region[r]))
    def instances(r, ext_id): return region[r].count(f'ExtResource("{ext_id}")')
    requirements = [
        ('village','enemy','pinkslime',5), ('village','pickup','crystal',4), ('village','chest','',2),
        ('forest','enemy','pinkbat',8), ('forest','enemy','spider',6), ('forest','pickup','key',3),
        ('forest','pickup','potion',5), ('forest','enemy','phantom',6), ('forest','bonfire','',2),
        ('lake','enemy','bomberplant',5), ('lake','pickup','crystal',6), ('lake','chest','',3),
        ('highlands','enemy','spinner',8), ('highlands','enemy','pinkslime',10), ('highlands','enemy','phantom',8),
        ('highlands','pickup','potion',7), ('highlands','chest','',4),
        ('ruins','enemy','spider',10), ('ruins','enemy','phantom',10), ('ruins','pickup','crystal',8), ('ruins','pickup','key',5),
        ('dungeon','enemy','spinner',10), ('dungeon','enemy','bomberplant',8), ('dungeon','enemy','pinkbat',12),
        ('dungeon','chest','',5), ('dungeon','pickup','key',8), ('dungeon','enemy','phantom',12), ('dungeon','pickup','crystal',12),
    ]
    for r, kind, target, count in requirements:
        if kind == 'enemy': have = enemies(r)[target]
        elif kind == 'pickup': have = pickups(r)[target]
        elif kind == 'chest': have = instances(r, '6_chest')
        else: have = instances(r, '7_fire')
        assert have >= count, (r, kind, target, have, count)
    assert 'respawn_delay' in text('scripts/enemy.gd') and 'queue_free()' not in text('scripts/enemy.gd')
    assert 'respawn_delay' in text('scripts/pickup.gd') and 'queue_free()' not in text('scripts/pickup.gd')
    assert 'reset_delay' in text('scripts/chest.gd')


def test_quest_visibility_and_guidance():
    npc_scene = text('scenes/npcs/quest_npc.tscn')
    npc_script = text('scripts/quest_npc.gd')
    hud = text('scripts/hud.gd')
    assert '[node name="NameLabel"' in npc_scene
    assert '[node name="InteractionHint"' in npc_scene
    assert 'add_to_group("quest_npcs")' in npc_script
    assert 'get_current_campaign_quest_id' in text('scripts/game_state.gd')
    assert 'GuideText' in text('scenes/ui/hud.tscn')
    assert '_refresh_guide' in hud


def test_movement_mobile_and_shop():
    player = text('scripts/player.gd')
    assert 'get_nodes_in_group("mobile_controls")' in player or 'get_first_node_in_group("mobile_controls")' in player
    assert 'velocity = Vector2.ZERO\n        move_and_slide()\n        return' not in player
    assert 'request_attack' in player and 'request_interact' in player
    assert (ROOT/'scripts/mobile_controls.gd').exists()
    assert (ROOT/'scenes/ui/mobile_controls.tscn').exists()
    main = text('scenes/main.tscn')
    assert 'mobile_controls.tscn' in main and '[editable path="MobileControls"]' in main
    assert (ROOT/'scripts/billing_manager.gd').exists()
    project = text('project.godot')
    assert 'BillingManager="*res://scripts/billing_manager.gd"' in project
    gs = text('scripts/game_state.gd')
    assert 'premium_coins' in gs and 'buy_shop_item' in gs
    hud_scene = text('scenes/ui/hud.tscn')
    assert '[node name="ShopPanel"' in hud_scene
    billing = text('scripts/billing_manager.gd')
    assert 'OS.has_feature("android")' in billing
