extends StaticBody2D
@export var requires_key: bool = true
var opened := false
func _ready() -> void:
    add_to_group("interactables")
func interact(_player: Node) -> void:
    if opened:
        return
    if requires_key and not GameState.use_item("key", 1):
        GameState.message.emit("O portão precisa de uma chave.")
        return
    opened = true
    $AnimatedSprite2D.play("open")
    collision_layer = 0
    collision_mask = 0
    GameState.message.emit("Portão aberto.")
