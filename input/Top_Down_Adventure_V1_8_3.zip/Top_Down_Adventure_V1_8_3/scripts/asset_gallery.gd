@tool
extends Node2D

@export var build_gallery: bool = false
@export var columns: int = 8

func _ready() -> void:
    if not Engine.is_editor_hint():
        _build()

func _process(_delta: float) -> void:
    if Engine.is_editor_hint() and build_gallery:
        build_gallery = false
        _build()

func _build() -> void:
    for child in get_children():
        child.queue_free()
    var file := FileAccess.open("res://data/asset_catalog.json", FileAccess.READ)
    if file == null:
        return
    var data = JSON.parse_string(file.get_as_text())
    if not data is Dictionary:
        return
    var index := 0
    for entry in data.get("files", []):
        var path := String(entry.get("path", ""))
        if not path.to_lower().ends_with(".png"):
            continue
        var tex = load(path)
        if tex == null:
            continue
        var holder := Node2D.new()
        holder.name = "Asset_%03d" % index
        holder.position = Vector2((index % columns) * 170 + 80, (index / columns) * 120 + 60)
        var sprite := Sprite2D.new()
        sprite.texture = tex
        var max_dim: float = maxf(float(tex.get_width()), float(tex.get_height()))
        if max_dim > 96.0:
            var s := 96.0 / max_dim
            sprite.scale = Vector2(s, s)
        elif max_dim <= 32.0:
            sprite.scale = Vector2(2.0, 2.0)
        holder.add_child(sprite)
        var label := Label.new()
        label.position = Vector2(-70, 52)
        label.size = Vector2(140, 36)
        label.text = path.get_file()
        label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
        label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
        label.add_theme_font_size_override("font_size", 8)
        holder.add_child(label)
        add_child(holder)
        index += 1
