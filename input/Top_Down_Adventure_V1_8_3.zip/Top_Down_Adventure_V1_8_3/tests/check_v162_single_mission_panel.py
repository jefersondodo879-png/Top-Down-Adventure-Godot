from pathlib import Path


def test_hud_has_single_mission_panel():
    hud_scene = Path('scenes/ui/hud.tscn').read_text(encoding='utf-8')
    assert '[node name="QuestPanel"' not in hud_scene, 'QuestPanel should be removed to avoid duplicate mission boxes'
    assert '[node name="GuidePanel"' in hud_scene, 'GuidePanel should remain as the single mission/guide box'


def test_hud_script_no_longer_uses_removed_quest_label():
    hud_script = Path('scripts/hud.gd').read_text(encoding='utf-8')
    assert 'quest_label' not in hud_script, 'hud.gd should not reference the removed QuestPanel/QuestText'
