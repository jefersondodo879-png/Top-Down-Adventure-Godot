extends Node

@onready var music: AudioStreamPlayer = $Music
@onready var sfx1: AudioStreamPlayer = $SFX1
@onready var sfx2: AudioStreamPlayer = $SFX2
@onready var sfx3: AudioStreamPlayer = $SFX3

var sfx_players: Array[AudioStreamPlayer] = []
var sfx_index: int = 0

func _ready() -> void:
    add_to_group("audio_manager")
    sfx_players = [sfx1, sfx2, sfx3]
    music.finished.connect(_restart_music)
    if not music.playing:
        music.play()

func _restart_music() -> void:
    music.play()

func _stream_for(sound_id: String) -> AudioStream:
    match sound_id:
        "attack":
            return preload("res://assets/audio/attack.wav")
        "hit":
            return preload("res://assets/audio/hit.wav")
        "pickup":
            return preload("res://assets/audio/pickup.wav")
        "chest":
            return preload("res://assets/audio/chest.wav")
        "inventory":
            return preload("res://assets/audio/inventory.wav")
        "potion":
            return preload("res://assets/audio/potion.wav")
        _:
            return null

func play_sfx(sound_id: String) -> void:
    var stream: AudioStream = _stream_for(sound_id)
    if stream == null or sfx_players.is_empty():
        return
    var player: AudioStreamPlayer = sfx_players[sfx_index]
    sfx_index = (sfx_index + 1) % sfx_players.size()
    player.stream = stream
    player.play()
