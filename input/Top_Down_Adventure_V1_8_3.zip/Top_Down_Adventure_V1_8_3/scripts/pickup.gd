extends Area2D

@export_enum("crystal", "key", "potion") var item_id: String = "crystal"
@export var amount: int = 1
@export var respawn_delay: float = 18.0
var collected := false
@onready var sprite: AnimatedSprite2D = $AnimatedSprite2D
@onready var static_sprite: Sprite2D = $PotionSprite

func _ready() -> void:
    body_entered.connect(_on_body_entered)
    _setup_visual()

func _setup_visual() -> void:
    if item_id == "potion":
        sprite.visible = false
        static_sprite.visible = true
    else:
        static_sprite.visible = false
        sprite.visible = true
        sprite.sprite_frames = load("res://resources/animations/%s_frames.tres" % item_id)
        sprite.play("idle")

func _on_body_entered(body: Node) -> void:
    if collected or not body.is_in_group("player"):
        return
    collected = true
    set_deferred("monitoring", false)
    GameState.add_item(item_id, amount)
    get_tree().call_group("audio_manager", "play_sfx", "pickup")
    if item_id != "potion" and sprite.sprite_frames.has_animation("collect"):
        sprite.play("collect")
        await get_tree().create_timer(0.35).timeout
    visible = false
    await get_tree().create_timer(respawn_delay).timeout
    _setup_visual()
    visible = true
    collected = false
    set_deferred("monitoring", true)
