# Third-party assets used in V1.8

## Ponk — Animated insect enemy assets

- Author: Ponk / PonkPixels
- Source: https://ponkpixels.itch.io/insect-enemies
- License: Creative Commons Attribution 4.0 International (CC BY 4.0)
- License URL: https://creativecommons.org/licenses/by/4.0/
- Use in this project: Beetle, Maggot, Mantis and acid projectile/splatter sprites.
- Modifications in this project: sprites are imported into Godot SpriteFrames, scaled/animated and used with custom gameplay logic.
- Attribution requirement: retain author/source/license credit in distributed game credits and documentation.

## OboroPixel — Characters Animations Asset Pack (Free version)

- Author: OboroPixel
- Source: https://oboropixel.itch.io/characters-animations-asset-pack
- License included with downloaded pack: personal and commercial use permitted; modification permitted; credit not required but appreciated; redistribution or resale of the asset is prohibited.
- Use in this project: Human Soldier with Sword & Shield and Monster Slime animation sprites.
- The original `License.txt` and `Contact.txt` from the downloaded pack are preserved under `assets/ThirdParty/OboroPixel_Characters/`.
- Raw source packs are not redistributed inside this project ZIP; only the PNGs actually used by the game are included.

## Publication note

Before publishing a release build, keep this file and the in-game Credits screen, and do not package the original downloaded ZIP/ASEPRITE source archives as redistributable game content.
