extends Area2D

@export var speed: float = 150.0
var direction := Vector2.RIGHT
var damage: int = 12
var lifetime := 2.6

func _ready() -> void:
    body_entered.connect(_on_body_entered)

func setup(move_direction: Vector2, attack_damage: int) -> void:
    direction = move_direction.normalized()
    damage = attack_damage
    rotation = direction.angle()

func _physics_process(delta: float) -> void:
    global_position += direction * speed * delta
    lifetime -= delta
    if lifetime <= 0.0:
        queue_free()

func _on_body_entered(body: Node) -> void:
    if body.is_in_group("player") and body.has_method("take_damage"):
        body.take_damage(damage)
        queue_free()
