extends Node

signal inventory_changed
signal equipment_changed
signal quests_changed
signal stats_changed
signal message(text: String)
signal profile_changed

var coins: int = 0
var premium_coins: int = 0
var xp: int = 0
var level: int = 1
var inventory: Dictionary = {
    "crystal": 0,
    "key": 0,
    "potion": 3,
    "scrap": 0,
    "sword_basic": 1,
    "armor_leather": 1
}
var equipped_weapon: String = "sword_basic"
var equipped_armor: String = ""
var weapon_levels: Dictionary = {"sword_basic": 1}
var item_definitions: Dictionary = {}
var quests: Dictionary = {}
var active: Dictionary = {}
var completed: Dictionary = {}
var visited_regions: Dictionary = {}
var ui_modal_open: bool = false
var selected_character: String = "hero"
var unlocked_characters: Dictionary = {"hero": true}
var adventure_pass_owned: bool = false
var pass_xp: int = 0
var character_definitions: Dictionary = {}
var last_player_position: Vector2 = Vector2(640, 500)

const CAMPAIGN_QUEST_COUNT := 36

func _ready() -> void:
    _load_items()
    _load_quests()
    _load_characters()

func _load_items() -> void:
    item_definitions.clear()
    var file := FileAccess.open("res://data/items.json", FileAccess.READ)
    if file == null:
        push_error("Não foi possível abrir items.json")
        return
    var parsed = JSON.parse_string(file.get_as_text())
    if parsed is Array:
        for entry in parsed:
            item_definitions[String(entry.get("id", ""))] = entry

func _load_quests() -> void:
    quests.clear()
    var file := FileAccess.open("res://data/quests.json", FileAccess.READ)
    if file == null:
        push_error("Não foi possível abrir quests.json")
        return
    var parsed = JSON.parse_string(file.get_as_text())
    if parsed is Array:
        for entry in parsed:
            quests[String(entry.get("id", ""))] = entry

func get_item_definition(item_id: String) -> Dictionary:
    return item_definitions.get(item_id, {})

func get_inventory_item_ids() -> Array[String]:
    var result: Array[String] = []
    for item_id in inventory.keys():
        if int(inventory.get(item_id, 0)) > 0:
            result.append(String(item_id))
    result.sort_custom(func(a: String, b: String) -> bool:
        var da: Dictionary = get_item_definition(a)
        var db: Dictionary = get_item_definition(b)
        var ta := String(da.get("type", "z"))
        var tb := String(db.get("type", "z"))
        if ta == tb:
            return String(da.get("name", a)) < String(db.get("name", b))
        return ta < tb
    )
    return result

func add_item(item_id: String, amount: int = 1) -> void:
    if amount <= 0:
        return
    inventory[item_id] = int(inventory.get(item_id, 0)) + amount
    inventory_changed.emit()
    report_event("collect", item_id, amount)

func _add_item_without_quest_progress(item_id: String, amount: int) -> void:
    if amount <= 0:
        return
    inventory[item_id] = int(inventory.get(item_id, 0)) + amount
    inventory_changed.emit()

func use_item(item_id: String, amount: int = 1) -> bool:
    if amount <= 0:
        return false
    var have := int(inventory.get(item_id, 0))
    if have < amount:
        return false
    inventory[item_id] = have - amount
    inventory_changed.emit()
    return true

func equip_item(item_id: String) -> bool:
    if int(inventory.get(item_id, 0)) <= 0:
        message.emit("Você não possui esse item.")
        return false
    var definition := get_item_definition(item_id)
    var item_type := String(definition.get("type", ""))
    if item_type == "armor":
        equipped_armor = item_id
    elif item_type == "weapon":
        equipped_weapon = item_id
        if not weapon_levels.has(item_id):
            weapon_levels[item_id] = 1
    else:
        message.emit("Esse item não pode ser equipado.")
        return false
    equipment_changed.emit()
    inventory_changed.emit()
    message.emit("Equipado: %s" % String(definition.get("name", item_id)))
    return true

func unequip_armor() -> void:
    equipped_armor = ""
    equipment_changed.emit()
    inventory_changed.emit()

func get_armor_shield() -> int:
    if equipped_armor.is_empty():
        return 0
    return int(get_item_definition(equipped_armor).get("shield", 0))

func get_weapon_level() -> int:
    if equipped_weapon.is_empty():
        return 0
    return int(weapon_levels.get(equipped_weapon, 1))

func get_weapon_damage() -> int:
    if equipped_weapon.is_empty():
        return 10
    var definition := get_item_definition(equipped_weapon)
    var base_damage := int(definition.get("base_damage", 20))
    return base_damage + maxi(0, get_weapon_level() - 1) * 6

func get_weapon_upgrade_cost() -> Dictionary:
    var weapon_level := maxi(1, get_weapon_level())
    return {"gold": 100 * weapon_level, "scrap": 2 * weapon_level}

func upgrade_weapon() -> bool:
    if equipped_weapon.is_empty():
        message.emit("Equipe uma arma antes de melhorar.")
        return false
    var current_level := get_weapon_level()
    if current_level >= 10:
        message.emit("Sua arma já está no nível máximo.")
        return false
    var cost := get_weapon_upgrade_cost()
    var gold_cost := int(cost.get("gold", 0))
    var scrap_cost := int(cost.get("scrap", 0))
    if coins < gold_cost:
        message.emit("Ouro insuficiente para a melhoria.")
        return false
    if int(inventory.get("scrap", 0)) < scrap_cost:
        message.emit("Sucata insuficiente para a melhoria.")
        return false
    coins -= gold_cost
    inventory["scrap"] = int(inventory.get("scrap", 0)) - scrap_cost
    weapon_levels[equipped_weapon] = current_level + 1
    inventory_changed.emit()
    equipment_changed.emit()
    stats_changed.emit()
    message.emit("Arma evoluída para +%d!" % (current_level + 1))
    return true

func _is_equipped(item_id: String) -> bool:
    return item_id == equipped_weapon or item_id == equipped_armor

func _would_remove_equipped(item_id: String, amount: int) -> bool:
    if not _is_equipped(item_id):
        return false
    return int(inventory.get(item_id, 0)) - amount <= 0

func sell_item(item_id: String, amount: int = 1) -> bool:
    if amount <= 0 or int(inventory.get(item_id, 0)) < amount:
        return false
    if _would_remove_equipped(item_id, amount):
        message.emit("Desequipe o último exemplar antes de vender.")
        return false
    var definition := get_item_definition(item_id)
    var unit_value := int(definition.get("sell_value", 0))
    if unit_value <= 0:
        message.emit("Esse item não pode ser vendido.")
        return false
    inventory[item_id] = int(inventory.get(item_id, 0)) - amount
    coins += unit_value * amount
    inventory_changed.emit()
    stats_changed.emit()
    message.emit("Vendido: %dx %s por %d ouro." % [amount, String(definition.get("name", item_id)), unit_value * amount])
    return true

func salvage_item(item_id: String, amount: int = 1) -> bool:
    if amount <= 0 or int(inventory.get(item_id, 0)) < amount:
        return false
    if _would_remove_equipped(item_id, amount):
        message.emit("Desequipe o último exemplar antes de quebrar.")
        return false
    var definition := get_item_definition(item_id)
    var unit_scrap := int(definition.get("salvage_value", 0))
    if unit_scrap <= 0:
        message.emit("Esse item não pode ser quebrado.")
        return false
    inventory[item_id] = int(inventory.get(item_id, 0)) - amount
    inventory["scrap"] = int(inventory.get("scrap", 0)) + unit_scrap * amount
    inventory_changed.emit()
    message.emit("Item quebrado: +%d sucata." % (unit_scrap * amount))
    return true

func can_accept(quest_id: String) -> bool:
    if not quests.has(quest_id) or active.has(quest_id) or completed.has(quest_id):
        return false
    var prereq := String(quests[quest_id].get("prereq", ""))
    return prereq.is_empty() or completed.has(prereq)

func accept_quest(quest_id: String) -> bool:
    if not can_accept(quest_id):
        return false
    active[quest_id] = 0
    var q: Dictionary = quests[quest_id]
    if String(q.get("event", "")) == "visit" and visited_regions.has(String(q.get("target", ""))):
        active[quest_id] = int(q.get("count", 1))
        call_deferred("_complete_quest", quest_id)
    message.emit("MISSÃO ACEITA: " + String(q.get("title", quest_id)))
    quests_changed.emit()
    return true

func report_event(event_type: String, target: String, amount: int = 1) -> void:
    if event_type == "visit":
        visited_regions[target] = true
    var finished: Array[String] = []
    for quest_id in active.keys():
        var q: Dictionary = quests[quest_id]
        if String(q.get("event", "")) != event_type:
            continue
        var q_target := String(q.get("target", ""))
        var matches := q_target == target
        if event_type == "kill" and q_target == "any_enemy":
            matches = true
        if not matches:
            continue
        active[quest_id] = mini(int(q.get("count", 1)), int(active[quest_id]) + amount)
        if int(active[quest_id]) >= int(q.get("count", 1)):
            finished.append(String(quest_id))
    for quest_id in finished:
        _complete_quest(quest_id)
    if not finished.is_empty() or amount > 0:
        quests_changed.emit()

func _complete_quest(quest_id: String) -> void:
    if not active.has(quest_id):
        return
    var q: Dictionary = quests[quest_id]
    active.erase(quest_id)
    completed[quest_id] = true
    coins += int(q.get("reward_coins", 0))
    var reward_xp := int(q.get("reward_xp", 0))
    xp += reward_xp
    add_pass_xp(reward_xp)
    while xp >= level * 120:
        xp -= level * 120
        level += 1
        message.emit("SUBIU DE NÍVEL! Agora você está no nível %d." % level)
    message.emit("MISSÃO CONCLUÍDA: %s  +%d moedas" % [String(q.get("title", quest_id)), int(q.get("reward_coins", 0))])
    stats_changed.emit()
    quests_changed.emit()

func get_current_campaign_quest_id() -> String:
    for i in range(1, CAMPAIGN_QUEST_COUNT + 1):
        var quest_id := "q%02d" % i
        if active.has(quest_id):
            return quest_id
        if not completed.has(quest_id):
            return quest_id
    return ""

func get_current_quest() -> Dictionary:
    var quest_id := get_current_campaign_quest_id()
    if quest_id.is_empty() or not quests.has(quest_id):
        return {}
    return quests[quest_id]

func get_quest_progress(quest_id: String) -> int:
    return int(active.get(quest_id, 0))

func get_active_quest_lines(max_lines: int = 4) -> Array[String]:
    var out: Array[String] = []
    var quest_id := get_current_campaign_quest_id()
    if not quest_id.is_empty() and active.has(quest_id):
        var q: Dictionary = quests[quest_id]
        out.append("• %s  %d/%d" % [String(q.get("title", quest_id)), int(active[quest_id]), int(q.get("count", 1))])
    if out.is_empty() and not quest_id.is_empty():
        out.append("Fale com o NPC marcado com !")
    elif quest_id.is_empty():
        out.append("Campanha concluída!")
    return out.slice(0, max_lines)

func get_quest_title(quest_id: String) -> String:
    if quests.has(quest_id):
        return String(quests[quest_id].get("title", quest_id))
    return quest_id

func get_quests_for_npc(npc_id: String) -> PackedStringArray:
    var result: Array[String] = []
    for quest_id in quests.keys():
        var quest: Dictionary = quests[quest_id]
        if String(quest.get("npc", "")) == npc_id:
            result.append(String(quest_id))
    result.sort()
    return PackedStringArray(result)

func _load_characters() -> void:
    character_definitions.clear()
    var file := FileAccess.open("res://data/characters.json", FileAccess.READ)
    if file == null:
        push_error("Não foi possível abrir characters.json")
        return
    var parsed = JSON.parse_string(file.get_as_text())
    if parsed is Array:
        for entry in parsed:
            character_definitions[String(entry.get("id", ""))] = entry

func get_character_definition(character_id: String) -> Dictionary:
    return character_definitions.get(character_id, {})

func is_character_unlocked(character_id: String) -> bool:
    return bool(unlocked_characters.get(character_id, false))

func select_character(character_id: String) -> bool:
    if not is_character_unlocked(character_id):
        message.emit("Esse personagem ainda está bloqueado.")
        return false
    selected_character = character_id
    profile_changed.emit()
    message.emit("Personagem selecionado: %s" % String(get_character_definition(character_id).get("name", character_id)))
    return true

func unlock_character_with_coins(character_id: String) -> bool:
    var definition := get_character_definition(character_id)
    if definition.is_empty() or String(definition.get("unlock_type", "")) != "coins":
        return false
    if is_character_unlocked(character_id):
        return true
    var cost := int(definition.get("unlock_cost", 0))
    if coins < cost:
        message.emit("Ouro insuficiente para liberar esse personagem.")
        return false
    coins -= cost
    unlocked_characters[character_id] = true
    stats_changed.emit()
    profile_changed.emit()
    message.emit("Personagem liberado: %s" % String(definition.get("name", character_id)))
    return true

func set_adventure_pass_owned(value: bool) -> void:
    adventure_pass_owned = value
    _grant_pass_rewards()
    profile_changed.emit()

func add_pass_xp(amount: int) -> void:
    if amount <= 0:
        return
    pass_xp += amount
    _grant_pass_rewards()
    profile_changed.emit()

func get_pass_level() -> int:
    return mini(10, 1 + int(pass_xp / 100))

func _grant_pass_rewards() -> void:
    if adventure_pass_owned and get_pass_level() >= 4:
        if not is_character_unlocked("slime"):
            unlocked_characters["slime"] = true
            message.emit("Passe de Aventura: personagem Slime liberado!")

func reset_new_game() -> void:
    var keep_unlocked := unlocked_characters.duplicate(true)
    var keep_pass := adventure_pass_owned
    var keep_pass_xp := pass_xp
    var keep_character := selected_character
    coins = 0
    premium_coins = 0
    xp = 0
    level = 1
    inventory = {
        "crystal": 0,
        "key": 0,
        "potion": 3,
        "scrap": 0,
        "sword_basic": 1,
        "armor_leather": 1
    }
    equipped_weapon = "sword_basic"
    equipped_armor = ""
    weapon_levels = {"sword_basic": 1}
    active.clear()
    completed.clear()
    visited_regions.clear()
    unlocked_characters = keep_unlocked
    adventure_pass_owned = keep_pass
    pass_xp = keep_pass_xp
    selected_character = keep_character if bool(unlocked_characters.get(keep_character, false)) else "hero"
    last_player_position = Vector2(640, 500)
    inventory_changed.emit()
    equipment_changed.emit()
    quests_changed.emit()
    stats_changed.emit()
    profile_changed.emit()

func export_save_data() -> Dictionary:
    return {
        "version": 18,
        "coins": coins,
        "premium_coins": premium_coins,
        "xp": xp,
        "level": level,
        "inventory": inventory.duplicate(true),
        "equipped_weapon": equipped_weapon,
        "equipped_armor": equipped_armor,
        "weapon_levels": weapon_levels.duplicate(true),
        "active": active.duplicate(true),
        "completed": completed.duplicate(true),
        "visited_regions": visited_regions.duplicate(true),
        "selected_character": selected_character,
        "unlocked_characters": unlocked_characters.duplicate(true),
        "adventure_pass_owned": adventure_pass_owned,
        "pass_xp": pass_xp,
        "last_player_position": [last_player_position.x, last_player_position.y]
    }

func import_save_data(data: Dictionary) -> void:
    coins = int(data.get("coins", 0))
    premium_coins = int(data.get("premium_coins", 0))
    xp = int(data.get("xp", 0))
    level = maxi(1, int(data.get("level", 1)))
    var saved_inventory: Dictionary = data.get("inventory", inventory)
    inventory = saved_inventory.duplicate(true)
    equipped_weapon = String(data.get("equipped_weapon", "sword_basic"))
    equipped_armor = String(data.get("equipped_armor", ""))
    var saved_weapon_levels: Dictionary = data.get("weapon_levels", {"sword_basic": 1})
    weapon_levels = saved_weapon_levels.duplicate(true)
    var saved_active: Dictionary = data.get("active", {})
    active = saved_active.duplicate(true)
    var saved_completed: Dictionary = data.get("completed", {})
    completed = saved_completed.duplicate(true)
    var saved_regions: Dictionary = data.get("visited_regions", {})
    visited_regions = saved_regions.duplicate(true)
    var saved_unlocks: Dictionary = data.get("unlocked_characters", {"hero": true})
    unlocked_characters = saved_unlocks.duplicate(true)
    unlocked_characters["hero"] = true
    adventure_pass_owned = bool(data.get("adventure_pass_owned", false))
    pass_xp = int(data.get("pass_xp", 0))
    var saved_pos: Variant = data.get("last_player_position", [640, 500])
    if saved_pos is Array and saved_pos.size() >= 2:
        last_player_position = Vector2(float(saved_pos[0]), float(saved_pos[1]))
    else:
        last_player_position = Vector2(640, 500)
    selected_character = String(data.get("selected_character", "hero"))
    if not is_character_unlocked(selected_character):
        selected_character = "hero"
    _grant_pass_rewards()
    inventory_changed.emit()
    equipment_changed.emit()
    quests_changed.emit()
    stats_changed.emit()
    profile_changed.emit()

func buy_shop_item(item_id: String, amount: int, price: int) -> bool:
    if price < 0 or amount <= 0:
        return false
    if coins < price:
        message.emit("Ouro insuficiente. Você precisa de %d moedas." % price)
        return false
    coins -= price
    _add_item_without_quest_progress(item_id, amount)
    stats_changed.emit()
    message.emit("Compra concluída: %dx %s por %d moedas." % [amount, item_id, price])
    return true

func add_premium_coins(amount: int) -> void:
    if amount <= 0:
        return
    premium_coins += amount
    stats_changed.emit()

func buy_premium_bundle(price: int) -> bool:
    if premium_coins < price:
        message.emit("Gemas insuficientes.")
        return false
    premium_coins -= price
    _add_item_without_quest_progress("potion", 10)
    _add_item_without_quest_progress("key", 5)
    _add_item_without_quest_progress("crystal", 5)
    stats_changed.emit()
    message.emit("Kit Aventureiro recebido: 10 poções, 5 chaves e 5 cristais.")
    return true
