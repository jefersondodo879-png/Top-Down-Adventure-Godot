# V1.7 RPG Systems Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build the approved V1.7 equipment, shield, summon, blacksmith, chest loot, market/salvage, and modal UI systems.

**Architecture:** GameState stores persistent item/equipment/economy state; Player applies combat stats; interactables request HUD modals; HUD enforces one modal and renders inventory/service flows. Existing scene instances remain editor-editable.

**Tech Stack:** Godot 4.7 GDScript, `.tscn`, JSON, Python static regression tests.

**Spec:** `docs/superpowers/specs/2026-09-16-v17-rpg-systems-design.md`

## Global Constraints
- Preserve PC + Android support.
- Preserve q01-q36 campaign.
- Reuse pack assets only.
- Keep structures/UI editable in Godot scenes.

---

### Task 1: Item database and inventory/equipment state
**Files:** Create `data/items.json`; Modify `scripts/game_state.gd`; Test `tests/check_v17_rpg_systems.py`.
- [ ] Add failing static checks for item definitions and required GameState APIs.
- [ ] Implement item loading, equipment, sell, salvage, weapon upgrade and stat APIs.
- [ ] Run checks.

### Task 2: Player shield and summon
**Files:** Modify `scripts/player.gd`; Create `scripts/crystal_guardian.gd`, `scenes/player/crystal_guardian.tscn`; Test `tests/check_v17_rpg_systems.py`.
- [ ] Add checks for shield and summon behavior hooks.
- [ ] Implement shield absorption/regeneration and R summon.
- [ ] Add guardian scene/script using existing crystal asset.

### Task 3: Chest loot and service NPCs
**Files:** Modify `scripts/chest.gd`, `scripts/quest_npc.gd`, `scenes/world/regions/01_vila_verde.tscn`; Test `tests/check_v17_rpg_systems.py`.
- [ ] Add checks for loot modal calls, smith service and market NPC.
- [ ] Implement stored chest loot and take APIs.
- [ ] Add `service_type` and merchant NPC; smith/market open appropriate HUD modal.

### Task 4: HUD equipment, service modals and modal isolation
**Files:** Modify `scenes/ui/hud.tscn`, `scripts/hud.gd`; Test `tests/check_v17_rpg_systems.py`.
- [ ] Add shield bar and editable Inventory Details, Loot, Blacksmith, Market panels.
- [ ] Implement slot selection, equip/salvage/sell, loot take-all, upgrade and one-modal policy.
- [ ] Hide passive HUD and block mobile gameplay controls while modal is open.

### Task 5: Android summon and regression verification
**Files:** Modify `scenes/ui/mobile_controls.tscn`, `scripts/mobile_controls.gd`, `README.md`; Test all tests.
- [ ] Add INVOCAR button and UI-block API.
- [ ] Run V1.7 tests plus all prior regression tests.
- [ ] Verify resource references and zip integrity.
