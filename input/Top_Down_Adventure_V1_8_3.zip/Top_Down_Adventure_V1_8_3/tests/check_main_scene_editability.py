from pathlib import Path
import re

root = Path(__file__).resolve().parents[1]
main = (root / 'scenes/main.tscn').read_text(encoding='utf-8')
required = [
    'World',
    'World/Regions/VilaVerde',
    'World/Regions/FlorestaSussurrante',
    'World/Regions/TerrasAltas',
    'World/Regions/LagoDeCristal',
    'World/Regions/RuinasCinzentas',
    'World/Regions/MasmorraAntiga',
]
missing = [p for p in required if f'[editable path="{p}"]' not in main]
if missing:
    raise SystemExit('MISSING_EDITABLE_PATHS: ' + ', '.join(missing))

# All manually placed structures must exist in region scene files as scene-tree nodes.
region_dir = root / 'scenes/world/regions'
structure_nodes = 0
for path in sorted(region_dir.glob('*.tscn')):
    text = path.read_text(encoding='utf-8')
    structure_nodes += len(re.findall(r'^\[node name="[^"]+" parent="Structures(?:/[^"]+)?"', text, flags=re.M))
if structure_nodes < 200:
    raise SystemExit(f'Expected >=200 editable structure nodes, found {structure_nodes}')
print(f'OK: editable main scene paths={len(required)} structure_nodes={structure_nodes}')
