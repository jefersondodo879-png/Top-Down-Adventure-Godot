extends Node2D

@export var move_speed: float = 110.0
@export var attack_range: float = 92.0
@export var attack_damage: int = 18
@export var attack_interval: float = 0.65

var owner_player: Node2D = null
var life_remaining: float = 12.0
var attack_timer: float = 0.0
var orbit_phase: float = 0.0

func setup(player: Node2D, duration: float) -> void:
    owner_player = player
    life_remaining = duration

func _process(delta: float) -> void:
    life_remaining -= delta
    attack_timer = maxf(0.0, attack_timer - delta)
    orbit_phase += delta * 2.0
    if life_remaining <= 0.0 or owner_player == null or not is_instance_valid(owner_player):
        queue_free()
        return
    var target_pos := owner_player.global_position + Vector2(cos(orbit_phase), sin(orbit_phase)) * 26.0
    global_position = global_position.move_toward(target_pos, move_speed * delta)
    var enemy := _nearest_enemy()
    if enemy != null and attack_timer <= 0.0:
        attack_timer = attack_interval
        if enemy.has_method("take_damage"):
            enemy.take_damage(attack_damage + GameState.level)
        scale = Vector2(1.35, 1.35)
    else:
        scale = scale.lerp(Vector2.ONE, minf(1.0, delta * 8.0))

func _nearest_enemy() -> Node2D:
    var nearest: Node2D = null
    var best := attack_range
    for node in get_tree().get_nodes_in_group("enemies"):
        if node is Node2D and is_instance_valid(node) and node.visible:
            var d := global_position.distance_to((node as Node2D).global_position)
            if d < best:
                best = d
                nearest = node as Node2D
    return nearest
