extends Area2D
@export var region_id: String = "village"
@export var region_name: String = "Vila Verde"
var visited := false
func _ready() -> void:
    add_to_group("region_triggers")
    body_entered.connect(_body_entered)
func _body_entered(body: Node) -> void:
    if visited or not body.is_in_group("player"):
        return
    visited = true
    GameState.report_event("visit", region_id, 1)
    GameState.message.emit("REGIÃO DESCOBERTA: " + region_name)
