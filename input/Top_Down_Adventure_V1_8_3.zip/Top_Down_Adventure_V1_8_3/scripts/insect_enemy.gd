extends CharacterBody2D

const ACID_PROJECTILE_SCENE = preload("res://scenes/enemies/acid_projectile.tscn")
const BEETLE_FRAMES = preload("res://resources/animations/beetle_frames.tres")
const MAGGOT_FRAMES = preload("res://resources/animations/maggot_frames.tres")
const MANTIS_FRAMES = preload("res://resources/animations/mantis_frames.tres")

@export_enum("beetle", "maggot", "mantis_boss") var enemy_type: String = "beetle"
@export var respawn_delay: float = 14.0

var max_health: int = 60
var health: int = 60
var speed: float = 38.0
var attack_damage: int = 10
var detection_range: float = 150.0
var attack_range: float = 22.0
var attack_cooldown: float = 0.0
var dead := false
var engaged := false
var facing := Vector2.DOWN
var spawn_position := Vector2.ZERO
var initial_collision_layer: int
var initial_collision_mask: int
var boss_phase: int = 1

@onready var sprite: AnimatedSprite2D = $AnimatedSprite2D

func _ready() -> void:
    add_to_group("enemies")
    spawn_position = global_position
    initial_collision_layer = collision_layer
    initial_collision_mask = collision_mask
    _configure_type()
    _reset_enemy()

func _configure_type() -> void:
    match enemy_type:
        "maggot":
            max_health = 75
            speed = 26.0
            attack_damage = 12
            detection_range = 180.0
            attack_range = 112.0
            sprite.sprite_frames = MAGGOT_FRAMES
        "mantis_boss":
            max_health = 520
            speed = 38.0
            attack_damage = 18
            detection_range = 260.0
            attack_range = 30.0
            sprite.sprite_frames = MANTIS_FRAMES
            scale = Vector2(1.6, 1.6)
            add_to_group("bosses")
        _:
            max_health = 60
            speed = 44.0
            attack_damage = 10
            detection_range = 155.0
            attack_range = 22.0
            sprite.sprite_frames = BEETLE_FRAMES

func _physics_process(delta: float) -> void:
    if dead:
        return
    attack_cooldown = maxf(0.0, attack_cooldown - delta)
    var player := get_tree().get_first_node_in_group("player") as Node2D
    if player == null:
        return
    var distance := global_position.distance_to(player.global_position)
    if enemy_type == "mantis_boss":
        engaged = distance <= detection_range or (engaged and distance <= 360.0)
        _update_boss_phase()
    if distance > detection_range:
        velocity = velocity.move_toward(Vector2.ZERO, 9.0)
        move_and_slide()
        _play_state("idle")
        return
    var dir := global_position.direction_to(player.global_position)
    if dir != Vector2.ZERO:
        facing = dir
    if enemy_type == "maggot":
        _maggot_combat(player, distance, dir)
    else:
        _melee_combat(player, distance, dir)

func _maggot_combat(player: Node2D, distance: float, dir: Vector2) -> void:
    if distance <= attack_range:
        velocity = Vector2.ZERO
        move_and_slide()
        if attack_cooldown <= 0.0:
            _shoot_acid(player)
    else:
        velocity = dir * speed
        move_and_slide()
        _play_state("run")

func _melee_combat(player: Node2D, distance: float, dir: Vector2) -> void:
    if distance <= attack_range:
        velocity = Vector2.ZERO
        move_and_slide()
        if attack_cooldown <= 0.0:
            _do_melee_attack(player)
    else:
        velocity = dir * speed
        move_and_slide()
        _play_state("run")

func _do_melee_attack(player: Node2D) -> void:
    attack_cooldown = 0.9 if enemy_type == "mantis_boss" else 1.15
    _play_state("attack")
    await get_tree().create_timer(0.24).timeout
    if dead:
        return
    if is_instance_valid(player) and global_position.distance_to(player.global_position) <= attack_range + 10.0 and player.has_method("take_damage"):
        player.take_damage(attack_damage)

func _shoot_acid(player: Node2D) -> void:
    attack_cooldown = 1.55
    _play_state("attack")
    await get_tree().create_timer(0.2).timeout
    if dead or not is_instance_valid(player):
        return
    var projectile := ACID_PROJECTILE_SCENE.instantiate() as Area2D
    get_tree().current_scene.add_child(projectile)
    projectile.global_position = global_position + facing.normalized() * 12.0
    if projectile.has_method("setup"):
        projectile.setup(global_position.direction_to(player.global_position), attack_damage)

func _direction_name() -> String:
    if abs(facing.x) > abs(facing.y):
        return "right" if facing.x > 0.0 else "left"
    return "down" if facing.y > 0.0 else "up"

func _play_state(state: String) -> void:
    var animation_name := state + "_" + _direction_name()
    if sprite.sprite_frames.has_animation(animation_name):
        if sprite.animation != animation_name or not sprite.is_playing():
            sprite.play(animation_name)

func _update_boss_phase() -> void:
    var ratio := float(health) / float(max_health)
    var new_phase := 1
    if ratio <= 0.33:
        new_phase = 3
    elif ratio <= 0.66:
        new_phase = 2
    if new_phase == boss_phase:
        return
    boss_phase = new_phase
    if boss_phase == 2:
        speed = 48.0
        attack_damage = 22
        GameState.message.emit("CHEFE: A Mantis Ancestral ficou enfurecida!")
    elif boss_phase == 3:
        speed = 58.0
        attack_damage = 27
        GameState.message.emit("CHEFE: Fase final! A Mantis Ancestral está mais rápida.")

func take_damage(amount: int) -> void:
    if dead:
        return
    health = maxi(0, health - amount)
    get_tree().call_group("audio_manager", "play_sfx", "hit")
    if health <= 0:
        _die()
    else:
        _play_state("hit")

func _die() -> void:
    dead = true
    engaged = false
    velocity = Vector2.ZERO
    collision_layer = 0
    collision_mask = 0
    GameState.report_event("kill", enemy_type, 1)
    if enemy_type == "mantis_boss":
        GameState.coins += 500
        GameState.add_item("scrap", 8)
        GameState.add_item("crystal", 5)
        GameState.stats_changed.emit()
        GameState.add_pass_xp(120)
        GameState.message.emit("BOSS DERROTADO! +500 Ouro, +8 Sucata, +5 Cristais, +120 XP do Passe")
        await get_tree().create_timer(0.8).timeout
        visible = false
        return
    if randf() < 0.35:
        GameState.add_item("scrap", 1)
    await get_tree().create_timer(0.5).timeout
    visible = false
    await get_tree().create_timer(respawn_delay).timeout
    global_position = spawn_position
    visible = true
    collision_layer = initial_collision_layer
    collision_mask = initial_collision_mask
    _reset_enemy()

func _reset_enemy() -> void:
    dead = false
    engaged = false
    boss_phase = 1
    health = max_health if enemy_type == "mantis_boss" else max_health + GameState.level * 3
    attack_cooldown = 0.0
    _play_state("idle")

func get_boss_name() -> String:
    return "Mantis Ancestral"

func get_boss_health_ratio() -> float:
    if max_health <= 0:
        return 0.0
    return clampf(float(health) / float(max_health), 0.0, 1.0)

func get_boss_health_text() -> String:
    return "%d / %d" % [health, max_health]

func is_boss_active() -> bool:
    return enemy_type == "mantis_boss" and engaged and not dead and visible
