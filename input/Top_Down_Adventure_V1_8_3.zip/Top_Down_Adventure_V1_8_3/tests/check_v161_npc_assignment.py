from pathlib import Path
import json

ROOT = Path(__file__).resolve().parents[1]
quests = json.loads((ROOT / 'data/quests.json').read_text(encoding='utf-8'))
by_npc = {}
for quest in quests:
    by_npc.setdefault(quest.get('npc', ''), []).append(quest['id'])

# Regression: the first campaign quest must be discoverable from the NPC id alone.
assert by_npc.get('elder', [None])[0] == 'q01', by_npc.get('elder')

# Runtime quest ownership must not depend only on a deep-instanced PackedStringArray,
# because those overrides can arrive empty in main.tscn/editor instancing.
game_state = (ROOT / 'scripts/game_state.gd').read_text(encoding='utf-8')
npc = (ROOT / 'scripts/quest_npc.gd').read_text(encoding='utf-8')
assert 'func get_quests_for_npc(' in game_state, 'GameState lacks data-driven NPC quest lookup'
assert 'GameState.get_quests_for_npc(npc_id)' in npc, 'Quest NPC still relies only on exported quest_ids'
assert 'for quest_id in _owned_quest_ids()' in npc, 'NPC interaction/marker does not use resolved quest ownership'

print('PASS: V1.6.1 NPC quest ownership regression')
