from pathlib import Path

MASTER = Path('scenes/00_PROJETO_EDITAVEL.tscn')
MENU = Path('scripts/main_menu.gd')
MENU_SCENE = Path('scenes/ui/main_menu.tscn')


def test_master_scene_exists_and_contains_gameplay_structure():
    assert MASTER.exists(), 'A cena mestra editável precisa existir'
    text = MASTER.read_text(encoding='utf-8')
    for needle in [
        '[node name="PROJETO_EDITAVEL"',
        '[node name="World" parent="."',
        '[node name="Player" parent="."',
        '[node name="HUD" parent="."',
        '[node name="MobileControls" parent="."',
        '[node name="Audio" parent="."',
    ]:
        assert needle in text, f'Faltando estrutura: {needle}'


def test_all_regions_and_major_instances_are_editable():
    text = MASTER.read_text(encoding='utf-8')
    paths = [
        'World',
        'World/Regions/VilaVerde',
        'World/Regions/FlorestaSussurrante',
        'World/Regions/TerrasAltas',
        'World/Regions/LagoDeCristal',
        'World/Regions/RuinasCinzentas',
        'World/Regions/MasmorraAntiga',
        'Player', 'HUD', 'Audio', 'MobileControls',
    ]
    for path in paths:
        assert f'[editable path="{path}"]' in text, f'{path} não está marcado editável'


def test_each_region_exposes_tilemap_and_manual_groups():
    region_dir = Path('scenes/world/regions')
    for region in sorted(region_dir.glob('*.tscn')):
        text = region.read_text(encoding='utf-8')
        for node in ['Ground', 'Details', 'StructureTiles', 'Structures', 'Objects', 'NPCs', 'EnemySpawns']:
            assert f'[node name="{node}"' in text, f'{region.name}: faltando {node}'


def test_menu_runs_the_same_editable_master_scene():
    text = MENU.read_text(encoding='utf-8')
    assert text.count('res://scenes/00_PROJETO_EDITAVEL.tscn') >= 2, 'Iniciar e Continuar devem carregar a cena mestra'
    assert 'res://scenes/main.tscn' not in text, 'Menu não deve mais iniciar a cena antiga'


def test_main_menu_has_editor_hint_node():
    text = MENU_SCENE.read_text(encoding='utf-8')
    assert 'EDITOR_ABRA_00_PROJETO_EDITAVEL' in text
