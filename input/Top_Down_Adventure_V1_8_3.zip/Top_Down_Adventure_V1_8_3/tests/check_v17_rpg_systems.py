from pathlib import Path
import json


def read(p):
    return Path(p).read_text(encoding='utf-8')


def test_item_database_and_equipment_api():
    p = Path('data/items.json')
    assert p.exists()
    items = {x['id']: x for x in json.loads(p.read_text(encoding='utf-8'))}
    for item_id in ['sword_basic','armor_leather','armor_iron','armor_crystal','scrap']:
        assert item_id in items
    assert items['armor_leather']['type'] == 'armor'
    assert items['armor_crystal']['shield'] > items['armor_leather']['shield']
    gs = read('scripts/game_state.gd')
    for needle in ['equipped_weapon', 'equipped_armor', 'func equip_item(', 'func sell_item(', 'func salvage_item(', 'func upgrade_weapon(', 'func get_armor_shield(', 'func get_weapon_damage(']:
        assert needle in gs


def test_player_has_armor_shield_and_summon():
    player = read('scripts/player.gd')
    for needle in ['current_shield', 'shield_regen_delay', 'func request_summon(', 'KEY_R', 'CRYSTAL_GUARDIAN_SCENE', 'GameState.get_weapon_damage()']:
        assert needle in player
    assert Path('scenes/player/crystal_guardian.tscn').exists()
    guardian = read('scripts/crystal_guardian.gd')
    assert 'get_nodes_in_group("enemies")' in guardian
    assert 'take_damage' in guardian


def test_chest_uses_loot_window_not_direct_reward():
    chest = read('scripts/chest.gd')
    assert 'loot: Dictionary' in chest
    assert 'open_loot' in chest
    assert 'func take_all(' in chest
    interact_block = chest.split('func interact',1)[1].split('func _generate_loot',1)[0]
    assert 'GameState.coins +=' not in interact_block


def test_smith_and_market_services_exist():
    npc = read('scripts/quest_npc.gd')
    assert 'service_type: String' in npc
    assert 'open_blacksmith' in npc
    assert 'open_market' in npc
    village = read('scenes/world/regions/01_vila_verde.tscn')
    assert 'service_type = "blacksmith"' in village
    assert 'Merchant_Lysa' in village
    assert 'service_type = "market"' in village


def test_hud_has_shield_service_panels_and_single_modal_policy():
    hud_scene = read('scenes/ui/hud.tscn')
    for node in ['ShieldCluster','ItemDetails','LootPanel','BlacksmithPanel','MarketPanel']:
        assert f'[node name="{node}"' in hud_scene
    hud = read('scripts/hud.gd')
    for needle in ['func open_loot(', 'func open_blacksmith(', 'func open_market(', 'func _open_modal(', 'func _close_all_modals(', 'set_ui_blocked', 'GameState.equip_item', 'GameState.salvage_item', 'GameState.sell_item', 'GameState.upgrade_weapon']:
        assert needle in hud


def test_android_has_summon_and_ui_block():
    scene = read('scenes/ui/mobile_controls.tscn')
    script = read('scripts/mobile_controls.gd')
    assert 'BtnSummon' in scene
    assert 'INVOCAR' in scene
    assert 'func set_ui_blocked(' in script
    assert 'request_summon' in script
