# V1.8 Menu, Characters, Pass, Save, Enemies and Bosses Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Deliver a testable V1.8 ZIP with menu/save, unlockable characters/pass shell, licensed insect enemies/boss, attribution and UI cleanup.

**Architecture:** Add a menu/profile layer in front of the existing gameplay scene, keep account/campaign state in `GameState`, persist it with a small JSON `SaveManager`, and isolate insect/boss behavior in focused enemy scripts/scenes. Character visuals are selected at player startup from generated SpriteFrames resources.

**Tech Stack:** Godot 4.7.2 / GDScript, TSCN/TRES resources, JSON data, pytest static regression tests.

**Spec:** `docs/superpowers/specs/2026-09-16-v18-menu-characters-bosses-design.md`

## Global Constraints
- Preserve Godot 4.7 compatibility.
- Preserve the 36-mission campaign and 226 editable structures.
- PC and Android must remain supported.
- Online mode remains disabled and labeled Coming Soon.
- No real-money charge is implemented in V1.8; billing remains a clearly labeled production placeholder.
- Only the confirmed licensed Ponk/OboroPixel assets are integrated.

---

### Task 1: Save/profile and character/pass state
- [ ] Write failing static tests for save/profile API and character catalog.
- [ ] Extend `GameState` with meta/profile fields and reset/load helpers.
- [ ] Add `SaveManager` autoload with JSON persistence/autosave.
- [ ] Add `data/characters.json` and pass reward helpers.
- [ ] Run targeted tests.

### Task 2: Main menu
- [ ] Write failing tests for menu scene and entrypoint.
- [ ] Create editable `main_menu.tscn` and `main_menu.gd`.
- [ ] Implement Start, Continue, Characters, Pass, Settings, Credits, disabled Online, PC Exit.
- [ ] Run targeted tests.

### Task 3: Alternate playable characters
- [ ] Write failing tests for player character selection hooks/resources.
- [ ] Copy only used OboroPixel PNGs and bundled license.
- [ ] Generate Soldier/Slime SpriteFrames resources.
- [ ] Update player animation selection/mirroring without breaking default hero.
- [ ] Run targeted tests.

### Task 4: Licensed insects and boss
- [ ] Write failing tests for insect assets/scenes/boss HUD.
- [ ] Copy only used Ponk assets and attribution docs.
- [ ] Generate directional insect SpriteFrames resources.
- [ ] Implement insect melee/ranged/boss behavior and acid projectile.
- [ ] Add editable spawns to regions and boss HUD.
- [ ] Run targeted tests.

### Task 5: Professional modal polish and regression cleanup
- [ ] Write failing tests for iconized dynamic lists and deferred cleanup.
- [ ] Add icons/minimum sizes/tooltips to loot/market/shop controls.
- [ ] Replace immediate `free()` list cleanup with `queue_free()`.
- [ ] Run all old and new static tests plus resource-reference checks.
- [ ] Create and integrity-check final ZIP.
