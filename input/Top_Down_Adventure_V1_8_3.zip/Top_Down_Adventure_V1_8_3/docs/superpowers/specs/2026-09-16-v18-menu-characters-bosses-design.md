# V1.8 Menu, Characters, Pass, Save, Enemies and Bosses Design

## Goal
Upgrade the existing Godot 4.7 top-down RPG with a professional main menu, persistent save/continue flow, unlockable playable characters, an adventure pass progression shell, licensed third-party enemies, a boss encounter, and clearer third-party attribution while preserving the existing campaign, inventory/equipment, PC/Android controls and editable world structure.

## Main menu and profile flow
`res://scenes/ui/main_menu.tscn` becomes the application entry scene. It contains Start Game, Continue, Characters, Adventure Pass, Online (disabled / Coming Soon), Settings, Credits and Exit (PC only). Start Game resets campaign progress while preserving account-like unlocks/pass state, writes a save and enters `main.tscn`. Continue is disabled without a save and otherwise loads it before entering gameplay.

## Save system
A `SaveManager` autoload writes JSON under `user://save_v18.json`. It persists currencies, XP/level, inventory, equipment, weapon levels, quest progress, visited regions, selected/unlocked characters, pass ownership/progress, and settings. It autosaves on state-changing signals and exposes explicit new-game/load APIs for the menu.

## Character system
The existing hero remains free/default. The OboroPixel free pack contributes two selectable characters: Human Soldier (unlockable with in-game gold) and Monster Slime (Adventure Pass reward). Because these supplied sprites are side-facing 96x96 animation cells rather than true four-direction top-down art, the player reuses the same animation for vertical movement and mirrors left/right. This preserves functionality while making the perspective limitation explicit in the project docs.

## Adventure Pass
The V1.8 pass is a progression shell, not a live paid product. Pass XP derives from normal XP gain and unlocks preview rewards. The premium activation button uses the existing billing placeholder and explicitly does not charge on Android. The Slime playable character is granted at the configured premium reward tier once the pass is active.

## Enemies and boss
Ponk's insect pack is integrated into `assets/ThirdParty/Ponk_Insects`. Beetle is a melee roaming enemy, Maggot is ranged and launches an acid projectile, and Mantis is a boss with a larger scale, multiple health thresholds, faster/aggressive phases, a dedicated boss health HUD, and improved rewards. Enemy nodes remain editable in region scenes.

## UI/UX
Existing modal exclusivity stays mandatory: Inventory, Shop, Loot, Blacksmith and Market hide gameplay HUD elements. Dynamic loot/market buttons receive item icons and more readable sizing, and dynamic lists use deferred deletion (`queue_free`) to avoid the previous locked-object error. The main menu uses large touch-friendly controls for PC and Android.

## Licensing
OboroPixel's included `License.txt` is retained in the project; commercial use/modification is allowed and redistribution/resale of the asset itself is prohibited. Ponk's itch.io page identifies the insect pack as CC BY 4.0; attribution, source URL and license URL are recorded in `THIRD_PARTY_ASSETS.md`. Raw third-party packs are not included; only the sprites used by the game are included.

## Testing
Static regression tests validate menu entry scene, save fields, character catalog/unlock paths, pass hooks, licensed asset documentation, insect/boss scene presence, boss HUD, no empty export enums, modal exclusivity, deferred dynamic-list cleanup, campaign continuity and resource references. Runtime testing must still be done in Godot 4.7.2 because the execution environment does not include Godot.
