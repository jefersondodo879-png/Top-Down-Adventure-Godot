# V1.6 Campaign, Mobile Controls and Shop Design

## Goals
- Make quests q01 through q36 a single linear campaign.
- Keep every quest completable even if the player explored or consumed world content early.
- Make quest NPCs easy to find and understand.
- Support 8-direction movement and attacking while moving on PC and Android.
- Add landscape Android touch controls.
- Add an editable in-game shop with gold purchases and a safe Play Billing-ready premium currency bridge.
- Preserve the editable world/region structure in main.tscn.

## Quest architecture
q01 has no prerequisite. Every subsequent quest qNN requires q(NN-1). Region scenes remain the source of NPC quest ownership; main.tscn must never override quest_ids with empty arrays. Enemy, pickup and chest nodes respawn/reset after a delay so objectives cannot become permanently impossible. Visit objectives remain retroactive through visited_regions.

Quest NPCs always show their name. A yellow ! means they can give the next campaign quest. A cyan ? means the current objective is to talk to that NPC. Nearby players see an interaction hint. The HUD shows the active quest or the next quest giver.

## Input architecture
PC retains WASD/arrows, Space/left mouse attack, E interact, Q potion, I/TAB inventory, B shop. Movement remains normalized 8-direction. Attack no longer zeroes velocity; movement continues while attack animation/damage timing runs.

Android uses a landscape virtual analog stick plus Attack, Action, Potion, Bag and Shop touch buttons. Mobile controls expose a movement vector and invoke public player/HUD methods, avoiding a dependency on project InputMap serialization.

## Shop architecture
GameState owns gold and premium currency balances and item purchasing. BillingManager is an autoload bridge. In desktop/editor it can simulate premium grants for testing. On Android it does not grant real currency until a Play Billing adapter is wired, and clearly reports that state. HUD contains an editable ShopPanel with gold item purchases and a premium-currency test section.

## Verification
Static tests verify the complete quest chain, NPC ownership, objective capacity per region, removal of main.tscn quest overrides, respawn safeguards, movement/attack behavior markers, mobile controls, shop/billing files and scene references. Zip integrity is checked. Godot runtime verification is not possible in this environment if no Godot executable is installed.
