# Edição manual da interface

A interface principal está em `res://scenes/ui/hud.tscn`.

Nós principais para editar no Scene Tree:

- `HUD/InventoryPanel` — inventário 6x5 do jogador.
- `HUD/ShopPanel` — loja de compra/premium.
- `HUD/LootPanel` — conteúdo de baús.
- `HUD/BlacksmithPanel` — Ferreiro Borin.
  - `VBox/Content/WeaponCard` — visual da arma atual.
  - `VBox/Content/UpgradeCard` — próximo dano, ouro e sucata.
  - `VBox/Footer` — botões de evolução/fechar.
- `HUD/MarketPanel` — Mercado da Vila.
  - `VBox/MarketGrid/MarketCard1` até `MarketCard8` — cards editáveis em duas colunas.
  - Cada card contém `Icon`, `Info/Name`, `Info/Meta`, `Info/Price` e `Sell`.
- `HUD/NPCDialoguePanel` — diálogo dos NPCs.

`res://scenes/main.tscn` mantém o HUD e as cenas das regiões como filhos editáveis. As estruturas do mapa continuam em `res://scenes/world/regions/` dentro do nó `Structures`, permitindo ajuste manual de posição e composição pelo editor.
