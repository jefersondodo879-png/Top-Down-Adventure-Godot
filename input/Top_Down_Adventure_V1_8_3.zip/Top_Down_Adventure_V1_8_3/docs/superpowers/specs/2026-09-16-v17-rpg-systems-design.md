# V1.7 RPG Systems Design

## Goal
Add equipment/armor shield, summon power, weapon upgrades at the blacksmith, lootable chests, market selling, item dismantling, and modal UI isolation while preserving PC/Android controls, campaign logic, and editor-editable scenes.

## Architecture
`GameState` remains the authoritative inventory/equipment/economy state and loads item definitions from `data/items.json`. `Player` consumes equipped armor/weapon stats and owns runtime health/shield/summon state. HUD owns all modal interfaces and enforces a single-modal policy. Chests and service NPCs delegate UI opening to HUD instead of granting/removing items directly.

## Systems
- Item database: consumables, materials, weapons, armors with rarity, sell value, salvage value and stats.
- Equipment: one weapon + one armor slot. Armor grants shield capacity; weapon level increases damage.
- Shield: absorbs damage before health and regenerates after a delay while armor is equipped.
- Summon: R on PC and INVOCAR on Android; crystal guardian follows player and damages nearby enemies for a limited duration, then cooldown.
- Blacksmith: Ferreiro Borin can open weapon upgrade UI. Upgrade consumes gold + scrap and raises weapon level.
- Chest loot: chest generates a stored loot dictionary, opens a modal showing contents, supports per-item take and TAKE ALL, and only resets after emptied/closed and delay.
- Market: new merchant NPC in Vila Verde opens market modal. Selected inventory item can be sold for gold.
- Salvage: selected non-essential equipment/material items can be dismantled from inventory into scrap. Equipped items cannot be sold or salvaged.
- Modal UI: only one major modal at a time. Opening inventory/chest/blacksmith/market/shop hides guide, hotbar, stats, messages and mobile gameplay controls; health/shield may remain. Closing restores gameplay HUD.
- PC/Android: keyboard/mouse and mobile controls stay supported. Android receives summon button; modal windows use normal Buttons and are touch-friendly.

## Constraints
- Godot 4.7.x.
- No generated art; reuse existing pack assets and text/icon fallbacks.
- All major UI panels and NPC/service nodes remain visible/editable in scene files.
- Existing q01-q36 campaign and scene-editable world structure must not regress.
