class_name DroppedItem
extends Area2D

const POTION_TEXTURE = preload("res://assets/Props_Items_(animated)/health_potion_item.png")
const CRYSTAL_STRIP = preload("res://assets/Props_Items_(animated)/crystal_item_anim_strip_6.png")
const KEY_STRIP = preload("res://assets/Props_Items_(animated)/key_item_anim_strip_6.png")
const GENERIC_ITEM_TEXTURE = preload("res://assets/Hud_Ui/select_icon_ui.png")

@export var item_id: String = "potion"
@export var amount: int = 1

@onready var sprite: Sprite2D = $Sprite2D
@onready var amount_label: Label = $Amount

func _ready() -> void:
    body_entered.connect(_on_body_entered)
    _refresh_visual()

func setup(new_item_id: String, new_amount: int = 1) -> void:
    item_id = new_item_id
    amount = maxi(1, new_amount)
    if is_node_ready():
        _refresh_visual()

func _refresh_visual() -> void:
    sprite.texture = _icon_for(item_id)
    amount_label.text = "x%d" % amount if amount > 1 else ""

func _icon_for(id: String) -> Texture2D:
    if id == "potion":
        return POTION_TEXTURE
    if id == "crystal":
        var crystal_atlas := AtlasTexture.new()
        crystal_atlas.atlas = CRYSTAL_STRIP
        crystal_atlas.region = Rect2(0, 0, 16, 16)
        return crystal_atlas
    if id == "key":
        var key_atlas := AtlasTexture.new()
        key_atlas.atlas = KEY_STRIP
        key_atlas.region = Rect2(0, 0, 16, 16)
        return key_atlas
    return GENERIC_ITEM_TEXTURE

func _on_body_entered(body: Node) -> void:
    if not body.is_in_group("player"):
        return
    set_deferred("monitoring", false)
    GameState.add_item(item_id, amount)
    get_tree().call_group("audio_manager", "play_sfx", "pickup")
    queue_free()
