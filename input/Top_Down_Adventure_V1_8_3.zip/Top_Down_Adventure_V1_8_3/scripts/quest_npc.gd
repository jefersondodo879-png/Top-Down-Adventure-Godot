extends CharacterBody2D

@export var npc_id: String = "elder"
@export var display_name: String = "NPC"
@export var quest_ids: PackedStringArray = []
@export var npc_tint: Color = Color.WHITE
@export var interaction_distance: float = 42.0
@export_enum("none", "blacksmith", "market") var service_type: String = "none"

@onready var sprite: AnimatedSprite2D = $AnimatedSprite2D
@onready var marker: Label = $QuestMarker
@onready var name_label: Label = $NameLabel
@onready var interaction_hint: Label = $InteractionHint

func _ready() -> void:
    add_to_group("interactables")
    add_to_group("quest_npcs")
    sprite.modulate = npc_tint
    sprite.play("idle_down")
    name_label.text = display_name
    interaction_hint.visible = false
    GameState.quests_changed.connect(_refresh_marker)
    _refresh_marker()

func _process(_delta: float) -> void:
    var player := get_tree().get_first_node_in_group("player") as Node2D
    if player == null:
        interaction_hint.visible = false
        return
    var nearby := global_position.distance_to(player.global_position) <= interaction_distance
    interaction_hint.visible = nearby
    if nearby:
        var action_name := "Falar"
        if service_type == "blacksmith": action_name = "Ferreiro"
        elif service_type == "market": action_name = "Mercado"
        interaction_hint.text = ("[AÇÃO] " if OS.has_feature("android") else "[E] ") + action_name

func _owned_quest_ids() -> PackedStringArray:
    var data_ids := GameState.get_quests_for_npc(npc_id)
    if not data_ids.is_empty():
        return data_ids
    return quest_ids

func _refresh_marker() -> void:
    marker.visible = false
    marker.text = "!"
    marker.modulate = Color(1.0, 0.92, 0.2, 1.0)
    for quest_id in _owned_quest_ids():
        if GameState.can_accept(String(quest_id)):
            marker.visible = true
            return
    var current_id := GameState.get_current_campaign_quest_id()
    if current_id.is_empty() or not GameState.active.has(current_id):
        return
    var quest: Dictionary = GameState.quests.get(current_id, {})
    if String(quest.get("event", "")) == "talk" and String(quest.get("target", "")) == npc_id:
        marker.text = "?"
        marker.modulate = Color(0.35, 0.95, 1.0, 1.0)
        marker.visible = true

func interact(_player: Node) -> void:
    GameState.report_event("talk", npc_id, 1)
    for quest_id in _owned_quest_ids():
        if GameState.accept_quest(String(quest_id)):
            var quest: Dictionary = GameState.quests[String(quest_id)]
            get_tree().call_group("hud", "open_npc_dialogue", display_name, String(quest.get("description", "")))
            return
    if service_type == "blacksmith":
        get_tree().call_group("hud", "open_blacksmith", self)
        return
    if service_type == "market":
        get_tree().call_group("hud", "open_market", self)
        return
    var current_id := GameState.get_current_campaign_quest_id()
    if current_id.is_empty():
        get_tree().call_group("hud", "open_npc_dialogue", display_name, "Você concluiu a campanha do Reino dos Cristais!")
    elif GameState.active.has(current_id):
        get_tree().call_group("hud", "open_npc_dialogue", display_name, "Conclua seu objetivo atual e volte quando precisar.")
    else:
        get_tree().call_group("hud", "open_npc_dialogue", display_name, "A próxima tarefa ainda depende da missão anterior.")
