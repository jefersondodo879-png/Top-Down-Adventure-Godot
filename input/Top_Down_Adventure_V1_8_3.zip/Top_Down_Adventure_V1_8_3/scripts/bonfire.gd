extends StaticBody2D
func _ready() -> void:
    add_to_group("interactables")
    $AnimatedSprite2D.play("idle")
func interact(player: Node) -> void:
    if player.has_method("heal"):
        player.heal(1000)
    GameState.report_event("interact", "bonfire", 1)
    GameState.message.emit("Fogueira: vida restaurada.")
