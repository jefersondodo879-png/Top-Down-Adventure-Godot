extends CharacterBody2D

@export_enum("pinkslime", "spider", "pinkbat", "phantom", "spinner", "bomberplant") var enemy_type: String = "pinkslime"
@export var max_health: int = 45
@export var speed: float = 35.0
@export var attack_damage: int = 10
@export var detection_range: float = 105.0
@export var attack_range: float = 17.0
@export var respawn_delay: float = 10.0
var health: int
var dead := false
var attacking := false
var facing_right := true
var spawn_position := Vector2.ZERO
var initial_collision_layer: int
var initial_collision_mask: int

@onready var sprite: AnimatedSprite2D = $AnimatedSprite2D

func _ready() -> void:
    add_to_group("enemies")
    spawn_position = global_position
    initial_collision_layer = collision_layer
    initial_collision_mask = collision_mask
    _reset_enemy()

func _physics_process(_delta: float) -> void:
    if dead:
        return
    var player := get_tree().get_first_node_in_group("player") as Node2D
    if player == null:
        return
    var distance := global_position.distance_to(player.global_position)
    if distance > detection_range:
        velocity = velocity.move_toward(Vector2.ZERO, 8.0)
        move_and_slide()
        _play_state("idle")
        return
    var dir := global_position.direction_to(player.global_position)
    facing_right = dir.x >= 0.0
    if distance <= attack_range:
        velocity = Vector2.ZERO
        move_and_slide()
        if not attacking:
            _do_attack(player)
    elif enemy_type != "bomberplant":
        velocity = dir * speed
        move_and_slide()
        _play_state("run")
    else:
        velocity = Vector2.ZERO
        _play_state("idle")

func _anim_for(state: String) -> String:
    if enemy_type in ["phantom", "pinkbat"]:
        var candidate := state + ("_right" if facing_right else "_left")
        if sprite.sprite_frames.has_animation(candidate):
            return candidate
    if sprite.sprite_frames.has_animation(state):
        return state
    return "idle_right" if facing_right and sprite.sprite_frames.has_animation("idle_right") else ("idle_left" if sprite.sprite_frames.has_animation("idle_left") else sprite.sprite_frames.get_animation_names()[0])

func _play_state(state: String) -> void:
    var anim := _anim_for(state)
    if sprite.animation != anim or not sprite.is_playing():
        sprite.play(anim)

func _do_attack(player: Node2D) -> void:
    attacking = true
    _play_state("attack")
    await get_tree().create_timer(0.28).timeout
    if is_instance_valid(player) and global_position.distance_to(player.global_position) <= attack_range + 5.0 and player.has_method("take_damage"):
        player.take_damage(attack_damage)
    await get_tree().create_timer(0.55).timeout
    attacking = false

func take_damage(amount: int) -> void:
    if dead:
        return
    health -= amount
    get_tree().call_group("audio_manager", "play_sfx", "hit")
    if health <= 0:
        _die()
    else:
        _play_state("hit")

func _die() -> void:
    dead = true
    attacking = false
    velocity = Vector2.ZERO
    collision_layer = 0
    collision_mask = 0
    _play_state("death")
    GameState.report_event("kill", enemy_type, 1)
    if randf() < 0.28:
        GameState.add_item("potion", 1)
    await get_tree().create_timer(0.7).timeout
    visible = false
    await get_tree().create_timer(respawn_delay).timeout
    global_position = spawn_position
    visible = true
    collision_layer = initial_collision_layer
    collision_mask = initial_collision_mask
    _reset_enemy()

func _reset_enemy() -> void:
    dead = false
    attacking = false
    health = max_health + GameState.level * 2
    sprite.sprite_frames = load("res://resources/animations/%s_frames.tres" % enemy_type)
    _play_state("idle")
