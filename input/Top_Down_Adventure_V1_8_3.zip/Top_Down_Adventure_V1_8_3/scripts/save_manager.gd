extends Node

const SAVE_PATH := "user://save_v18.json"
const SETTINGS_PATH := "user://settings_v18.json"

var settings: Dictionary = {
    "master_volume": 0.85,
    "music_volume": 0.75,
    "sfx_volume": 0.85,
    "fullscreen": false
}
var _autosave_enabled := false

func _ready() -> void:
    _load_settings()
    GameState.inventory_changed.connect(_request_autosave)
    GameState.equipment_changed.connect(_request_autosave)
    GameState.quests_changed.connect(_request_autosave)
    GameState.stats_changed.connect(_request_autosave)
    GameState.profile_changed.connect(_request_autosave)

func has_save() -> bool:
    return FileAccess.file_exists(SAVE_PATH)

func start_new_game() -> void:
    _autosave_enabled = false
    GameState.reset_new_game()
    _autosave_enabled = true
    save_game()

func save_game() -> bool:
    var file := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
    if file == null:
        push_error("Não foi possível salvar o jogo.")
        return false
    file.store_string(JSON.stringify(GameState.export_save_data(), "  "))
    return true

func load_game() -> bool:
    if not has_save():
        return false
    var file := FileAccess.open(SAVE_PATH, FileAccess.READ)
    if file == null:
        return false
    var parsed = JSON.parse_string(file.get_as_text())
    if not parsed is Dictionary:
        return false
    _autosave_enabled = false
    GameState.import_save_data(parsed)
    _autosave_enabled = true
    return true

func _request_autosave() -> void:
    if not _autosave_enabled or not has_save():
        return
    call_deferred("save_game")

func get_settings() -> Dictionary:
    return settings.duplicate(true)

func update_settings(values: Dictionary) -> void:
    for key in values.keys():
        settings[key] = values[key]
    _apply_settings()
    _save_settings()

func _load_settings() -> void:
    if FileAccess.file_exists(SETTINGS_PATH):
        var file := FileAccess.open(SETTINGS_PATH, FileAccess.READ)
        if file != null:
            var parsed = JSON.parse_string(file.get_as_text())
            if parsed is Dictionary:
                for key in parsed.keys():
                    settings[key] = parsed[key]
    _apply_settings()

func _save_settings() -> void:
    var file := FileAccess.open(SETTINGS_PATH, FileAccess.WRITE)
    if file != null:
        file.store_string(JSON.stringify(settings, "  "))

func _apply_settings() -> void:
    var master_db := linear_to_db(clampf(float(settings.get("master_volume", 0.85)), 0.0, 1.0))
    AudioServer.set_bus_volume_db(AudioServer.get_bus_index("Master"), master_db)
    if not OS.has_feature("android"):
        DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_FULLSCREEN if bool(settings.get("fullscreen", false)) else DisplayServer.WINDOW_MODE_WINDOWED)
